# R43.38(사용자 11-14): 판 종류 — 업데이트 알림에서 오류 수정판과 기능 추가판을 나눠 보이게(오류 없는 분은 오류 수정판을 안 받아도 되게).
#  release/<판>_설명.txt 모양:
#   1줄  제목(앞 표시는 자동으로 붙음: 【중요】 / [새 기능] / [오류 수정])
#   그다음 머리줄(빈 줄 전까지, 순서 상관없음):
#     종류: 중요 | 새 기능 | 오류 수정      (꼭 있어야 함 — 관문 c15·make_release 가 막음)
#     번호: 2, 34                           (관련 번호. 비우거나 '공통' = 설치기·모든 번호)
#     받을 사람: 34번을 쓰면서 지도를 움직일 때 프레임이 떨어지는 분   (꼭 있어야 함)
#   나머지 = 바뀐 내용(유저에게 보일 글). 줄 앞에 【중요】·[새 기능]·[오류 수정] 을 붙여 줄마다 종류를 알려도 됨.
#  판 종류는 판 안에서 가장 큰 것: 중요 > 새 기능 > 오류 수정.
import re
KINDS={'중요':'important','새 기능':'feature','오류 수정':'fix'}
TAG={'important':'【중요】','feature':'[새 기능]','fix':'[오류 수정]'}
# 지난 판(종류 칸이 생기기 전) — 03_수정내역·판 설명으로 나눔
RETRO={
 'R43.28':('feature',[],'설치기에서 바로 업데이트를 받고 싶은 분'),
 'R43.29':('fix',[],'게임 안 종합 진단 창이 설치 안 한 번호까지 문제로 세던 분'),
 'R43.30':('feature',[],'업데이트 진행 상황(막대·남은 시간)을 보고 싶은 분'),
 'R43.31':('feature',[],'업데이트할 때 새 폴더가 생기는 게 싫은 분(같은 폴더에 덮어쓰기)'),
 'R43.32':('fix',[],'백신 때문에 "설치 자료 파일이 없습니다"로 설치가 막히던 분'),
 'R43.33':('fix',[2],'2번 자동논공으로 준 담당이 세이브를 불러오면 사라지던 분'),
 'R43.34':('fix',[2],'2번 자동논공 "reason=13" 창이 뜨던 분'),
 'R43.35':('fix',[2],'2번 자동논공 "reason=12" 창이 뜨던 분'),
 'R43.36':('fix',[2],'2번 자동논공 내정 보상이 세이브 뒤 사라지던 분'),
 'R43.37':('fix',[2],'2번 자동논공이 안 된다고 제보하려는 분(상태 창 요약)'),
}
def parse(text):
    """설명 글 → (title, kind, items, who, notes, errors)"""
    lines=text.strip('﻿').strip().splitlines();err=[]
    if not lines:return '', '', [], '', '', ['설명 글이 비었음']
    title=lines[0].strip();kind='';items=[];who='';i=1;seen=set()
    while i<len(lines) and lines[i].strip():
        m=re.match(r'^\s*(종류|번호|받을 사람)\s*:\s*(.*?)\s*$',lines[i])
        if not m:break
        k,v=m.group(1),m.group(2);seen.add(k)
        if k=='종류':
            if v not in KINDS:err.append('종류 값이 이상함: "%s" (중요 / 새 기능 / 오류 수정 중 하나)'%v)
            else:kind=KINDS[v]
        elif k=='번호':
            if v and v!='공통':
                for x in re.split(r'[,\s·]+',v):
                    x=x.strip().rstrip('번')
                    if not x:continue
                    if not x.isdigit() or not 0<=int(x)<=99:err.append('번호가 이상함: "%s"'%x)
                    elif int(x) not in items:items.append(int(x))
        else:who=v
        i+=1
    if '종류' not in seen:err.append('"종류:" 줄이 없음(제목 다음 줄에 종류: 중요 / 새 기능 / 오류 수정)')
    if '받을 사람' not in seen or not who:err.append('"받을 사람:" 줄이 없거나 비었음(이런 분만 받으세요 한 줄)')
    if kind=='fix' and not items and '번호' not in seen:err.append('오류 수정판은 "번호:" 줄이 있어야 함(공통이면 번호: 공통)')
    notes='\n'.join(lines[i:]).strip()
    for t in TAG.values():
        if title.startswith(t):title=title[len(t):].strip()
    if kind:title=TAG[kind]+' '+title
    return title,kind,sorted(items),who,notes,err
SEP=' · '
def date_text(date,kind,title):
    """옛 설치기(R43.37 이하)는 버튼 글자를 못 바꾸지만 판 목록의 date 칸은 그대로 보여 줌(시작 기록 줄·업데이트 탭 목록·설명 머리·받기 확인 창).
    → date 칸 = '2026-11-14 · 【중요】 짧은 제목'. 새 설치기(Update.cs Parse)는 ' · ' 앞만 날짜로 씀."""
    d=(date or '').split(SEP)[0].strip()
    if not kind:return d
    t=title or ''
    for x in TAG.values():
        if t.startswith(x):t=t[len(x):].strip()
    t=re.sub(r'^통합패치\s+R\d+\.\d+\s*[—-]\s*','',t).strip()
    if len(t)>40:t=t[:39]+'…'
    return d+SEP+TAG[kind]+(' '+t if t else '')
def retro(rel):
    """index.json 의 지난 판에 종류가 없으면 RETRO 로 채우고 제목 앞 표시를 붙임. date 칸에도 종류 글자(옛 설치기용)"""
    if not rel.get('kind'):
        k=RETRO.get(rel.get('tag'))
        if not k:return rel
        rel['kind'],rel['items'],rel['who']=k[0],list(k[1]),k[2]
        t=rel.get('title','')
        if not any(t.startswith(x) for x in TAG.values()):rel['title']=TAG[k[0]]+' '+t
    rel['date']=date_text(rel.get('date',''),rel['kind'],rel.get('title',''))
    return rel
