#!/bin/bash
# 새 대화(빈 작업 공간)에서 통합패치 작업 환경(/home/claude/r41)을 되살린다. 11-13 인수인계용.
#
# 쓰는 법:  bash 복원_새작업공간.sh <소스 ZIP 경로>
#
# 미리 할 것(인수인계 문서 3장):
#  (1) PC 의 바탕화면\통합패치\작업재료_R31_20261019 에서 가장 새 SAN14CE_통합패치_소스_R43정식_*_1of1.zip 을
#      device_stage_files 로 작업 공간에 가져온다(약 23MB). 이 ZIP 안이 r41 폴더 통째(꾸러미 DLL·앞판 꾸러미 포함).
#  (2) 깃허브 저장소 wprkfdid12-ux/san14ce-integrated-patch 를 add_repo(access=push) 로 붙이고
#      /home/claude/san14ce-integrated-patch 에 clone 한다. 11월7일 기본판(1.1GB)은 그 저장소 updates/base 조각에서 되살린다.
#
# 하는 일: 소스 ZIP 풀기 → 기본판 조각 풀기·지문 확인 → 도구 확인 → 꾸러미 다시 만들기 → 지금 깃허브 판과 같은지 대조 → 관문 빠른 점검
set -e
Z=$1; H=/home/claude; R=$H/r41; G=$H/san14ce-integrated-patch
[ -n "$Z" ] && [ -f "$Z" ] || { echo "소스 ZIP 경로를 주세요"; exit 1; }
[ -e "$R" ] && { echo "$R 가 이미 있음 — 그대로 쓰거나, 다시 하려면 먼저 옮길 것"; exit 1; }
[ -d "$G/updates/base" ] || { echo "깃허브 저장소 clone 이 없음: $G (add_repo 후 git clone)"; exit 1; }

echo "== 1. 도구 확인"
miss=""; for t in clang ld.lld llvm-rc python3 zip unzip git gh file; do command -v $t >/dev/null || miss="$miss $t"; done
[ -z "$miss" ] || { echo "없는 도구:$miss — 이 작업 공간에서는 빌드 불가(설치는 네트워크 설정 필요)"; exit 1; }
echo "   clang·lld·llvm-rc·python3·zip·git·gh 있음"

echo "== 2. 소스 ZIP 풀기 → $R"
cd $H && unzip -q "$Z"
[ -f "$R/build_all.sh" ] || { echo "ZIP 안에 r41 폴더가 없음"; exit 1; }

echo "== 3. 11월7일 기본판 되살리기(깃허브 base 조각)"
B="$R/final_r43/통합패치 11월 7일 최종판"; mkdir -p "$B"
for p in "$G"/updates/base/*.zip; do unzip -q -o "$p" -d "$B"; done
(cd "$B" && sha256sum -c --quiet SHA256SUMS.txt) && echo "   기본판 $(grep -c '' "$B/SHA256SUMS.txt")개 지문 일치"

echo "== 3b. 꾸러미 재료(예전에 올린 파일 사본) 되살리기"
python3 "$R/복원자료/되살리기.py"

echo "== 4. 꾸러미 다시 만들기(overlay_r43/pkg)"
cd $R && python3 build_overlay_r43.py >/tmp/복원_overlay.log 2>&1 || { tail -20 /tmp/복원_overlay.log; exit 1; }

echo "== 5. 지금 깃허브에 올린 판과 대조"
PAN=$(grep -o 'Version="R[0-9.]*"' installer101/Spec.cs | cut -d'"' -f2)
LZ=$(ls "$G"/updates/$PAN/*.zip 2>/dev/null | head -1)
if [ -n "$LZ" ]; then
  python3 - "$LZ" <<'EOF'
import sys,zipfile,re
z=zipfile.ZipFile(sys.argv[1]);gh={}
for l in z.read('SHA256SUMS.txt').decode('utf-8-sig').splitlines():
    if l.strip():h,f=l.split(None,1);gh[f.strip().lstrip('*')]=h
me={}
for l in open('/home/claude/r41/overlay_r43/pkg/SHA256SUMS.txt',encoding='utf-8-sig'):
    if l.strip():h,f=l.split(None,1);me[f.strip().lstrip('*')]=h
d=[f for f in set(gh)|set(me) if gh.get(f)!=me.get(f) and not f.startswith('README_덮어쓰기_')]   # 판 ZIP 목록에는 덮어쓰기 안내 글이 안 들어감
print('   깃허브 판과 파일 지문 %s (%d개)'%('모두 같음' if not d else '다름 %d개: %s'%(len(d),', '.join(sorted(d)[:8])),len(me)))
EOF
else echo "   깃허브에 $PAN 폴더 없음 — 대조 생략"; fi

echo "== 6. 관문 빠른 점검"
python3 교훈_점검/관문.py --빨리 2>&1 | tail -4
echo
echo "복원 끝: 판 $PAN. 다음은 인수인계 문서 4장(평소 작업 순서)."
