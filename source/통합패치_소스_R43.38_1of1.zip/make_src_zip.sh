#!/bin/bash
# 소스 보관 ZIP: bash make_src_zip.sh R43 → /mnt/user-data/outputs/SAN14CE_통합패치_소스_<판>_1of1.zip (overlay_r43·zip·임시 제외. 11-13: build_overlay_r43.py 가 쓰는 앞판 꾸러미 overlay_r42g·g2·h·i4/pkg 는 넣음 — 새 작업 공간 복원용)
set -e; TAG=$1; [ -n "$TAG" ] || { echo "판 이름 필요"; exit 1; }
OUT=/mnt/user-data/outputs/SAN14CE_통합패치_소스_${TAG}_1of1.zip; rm -f "$OUT"
cd /home/claude && zip -qr "$OUT" r41 -x 'r41/overlay_r43/*' 'r41/overlay_r42i/*' 'r41/overlay_r42i2/*' 'r41/overlay_r42i3/*' 'r41/overlay_*/new/*' 'r41/*.zip' 'r41/**/*.zip' 'r41/build_out/*.o' 'r41/build_tc/lib/*.bak*' 'r41/payload_r43/**/*.dll' 'r41/final_r43/*' 'r41/ai_compat/v1514/pkg/*' 'r41/ai_compat/v1514/dist/*' 'r41/ai_compat/v1514/work/*' 'r41/ai_compat/v1514/out/*.dll' 'r41/ai_compat/v1514/out/*.exe' 'r41/release/*'
# 11-13: 꾸러미 안의 ZIP(8번 python312.zip 등)은 꾸러미 파일이라 넣어야 함 — 위에서 *.zip 을 빼서 따로 더함
(cd /home/claude && find r41/newpkg/payload_new r41/newpkg/payload_cur -name '*.zip' -print | zip -q "$OUT" -@)
sha256sum "$OUT"; python3 -c "import zipfile,sys;print(len(zipfile.ZipFile(sys.argv[1]).namelist()),'files')" "$OUT"
