# R43: 게임 2026-11-05 업데이트판(0x6ad06f53 / 0x2a02000 / 782cf229…) 호환 — 정식판(11월5일 최종판 = 11월2일 + R42g2·R42h·R42i4) 위에 덮어쓰는 '누적' 판
#  바뀜: (1) 바이너리 모듈 전부 새 판 주소(apply_new + apply_data_new + ic_port_r43) (2) 우리 소스 모듈 전부 다시 빌드(version.h 새 판·R43F 오류창·Diag)
#        (3) 13번 리졸버 번역 재빌드 (4) 11번 3D 런타임 새 판 빌드 (5) 데이터: 24번 fixdata 새 원본/미적용본, 10번·31번 rdb 새 원본 위에 우리 레코드
#        (6) 설치기 소스(새 판 해시·판 라벨·R43F/R43D/R43E 해석) (7) manifest: version/game/Values/File sha/Known
#  검사: XML·해시·누적 파일 + 모듈 DLL 마다 [Mod] 등록 ini + data Values == 실제 파일 해시
import time,hashlib,os,re,shutil,zipfile,subprocess,sys
# 11-13 인수인계: 예전에 올린 파일 사본(uploads)이 없는 새 작업 공간에서는 복원_새작업공간.sh 가 만든 r41/복원자료/uploads 를 씀
#  (꾸러미가 읽는 141개 = 기본판과 같은 93개는 기본판에서 복사 + 다른 48개는 복원자료/uploads_diff 에 사본). 내용은 똑같음.
UP='/mnt/user-data/uploads/통합패치'
if not os.path.isdir(UP+'/통합패치 11월2일 최종판'):UP='/home/claude/r41/복원자료/uploads/통합패치'
FINAL=UP+'/통합패치 11월2일 최종판'
FINAL5=UP+'/통합패치 11월 5일 최종판'   # data/model101·screen101 (11월2일 사본엔 없음)
PREV=['/home/claude/r41/overlay_r42i4/pkg','/home/claude/r41/overlay_r42h/pkg','/home/claude/r41/overlay_r42g2/pkg','/home/claude/r41/overlay_r42g/pkg']
OUT='/home/claude/r41/overlay_r43';PKG=OUT+'/pkg';NEW=OUT+'/new';R='/home/claude/r41';PAY=R+'/newpkg/payload_new';CUR=R+'/newpkg/payload_cur';DATA=R+'/newpkg/data_new'
NEWGAME_SHA='782cf229a56cdde2b95399e0e7536740b3f5e96bea702679365e4dad061abdce';OLDGAME_SHA='87ed4e46590e0939c9efcaef14fa0f892917604dfda86e0a4be319fccffa2d6a'
PREV101=UP+'/통합패치 11월 5일 최종판/data'   # 옛 게임판(1.0.1) 원본 색인 — 새 판에서 옛 레코드가 남은 색인을 되돌릴 때 비교용
VER='R43';PART_MAX=4_500_000
def sha(b):return hashlib.sha256(b).hexdigest()
def shaf(p):return sha(open(p,'rb').read())
shutil.rmtree(OUT,ignore_errors=True);os.makedirs(PKG);os.makedirs(NEW)
def put_new(rel,data):
    p=NEW+'/'+rel;os.makedirs(os.path.dirname(p),exist_ok=True);open(p,'wb').write(data);return sha(data)
def locate(rel):
    for d in [NEW]+PREV+[FINAL5,FINAL]:
        p=d+'/'+rel
        if os.path.exists(p):return p
    return None
m=open(PREV[0]+'/support/manifest101.xml','rb').read().decode('utf-8')
known_add=[];replaced=[];added=[]
SKIP_NAMES={'적용_보고.txt','자료_적용_보고.txt','느슨한지문_적용_보고.txt','기록칸_적용_보고.txt','기록칸_적용_보고2.txt'}
def _skip(rel):return os.path.basename(rel) in SKIP_NAMES or (rel.count('/')==0 and rel.endswith('.txt')) or ('_보고' in os.path.basename(rel) and rel.endswith('.txt'))
# (1)(2)(3)(4) payload: payload_new 의 모든 파일 중 정식판(사슬)과 다른 것
for root,_,fs in os.walk(PAY):
    for fn in sorted(fs):
        if fn in SKIP_NAMES or fn.endswith('.ic_port_r43.txt') or ('_보고' in fn and fn.endswith('.txt')):continue
        full=os.path.join(root,fn);rel='support/payload/'+os.path.relpath(full,PAY).replace('\\','/')
        data=open(full,'rb').read();h=sha(data);old=locate(rel)
        if old and shaf(old)==h:continue
        put_new(rel,data)
        if not old:
            mm=re.search(r'source="%s" sha256="([0-9a-f]{64})"'%re.escape(rel),m)
            if mm:old=True;oh_m=mm.group(1)   # 작업 공간에 옛 사본은 없지만(큰 파일) manifest 에 있는 파일
        if old:
            oh=shaf(old) if old is not True else oh_m;replaced.append((rel,oh,h))
            n=m.count(f'sha256="{oh}"')
            if n==0:print('주의: manifest 에 없는 옛 해시(교체만)',rel)
            m=m.replace(f'source="{rel}" sha256="{oh}"',f'source="{rel}" sha256="{h}"')
            known_add.append((oh,'R42i4 '+os.path.basename(rel)))
        else:added.append((rel,h))
# R43 시험6: 17번 옛 이식본 3개는 manifest 에서 빼고 옛 해시를 Known 에 남김(설치기가 state.xml 기록대로 지움). 큰 자료 파일(0002/*.bin 등)은 작업 공간에 없어도 manifest 에 남긴다.
REMOVED=['support/payload/f17/SAN14Mods/ModPack/SAN14_Stats200.dll','support/payload/f17/SAN14_Stats200Reader.dll','support/payload/f17/SAN14Mods/modules/Stats200Reader.ini',
         # R43.38(P254, 사용자 11-14): 2번 자동 논공 삭제 — 자동논공 새 엔진과 등록 파일(설치기가 설치 기록대로 [갱신] 때 지움)
         'support/payload/f02/SAN14_AutoMerit.dll','support/payload/f02/SAN14Mods/modules/AutoPersonnelRepairMerit.ini']
for rel in REMOVED:
    mm=re.search(r'  <File target="([^"]+)" source="%s" sha256="([0-9a-f]{64})"[^\n]*\n'%re.escape(rel),m)
    if mm:m=m.replace(mm.group(0),'');known_add.append((mm.group(2),('R43.38 removed ' if '/f02/' in rel else 'R43 removed ')+os.path.basename(rel)));print('제거 항목',mm.group(1))
    else:print('제거 대상이 manifest 에 없음',rel)
# 새 파일(Diag) manifest 항목
for rel,h in added:
    tgt=rel.replace('support/payload/base/','').replace('support/payload/','')
    if rel.startswith('support/payload/base/'):
        tgt=rel[len('support/payload/base/'):];when='base';idn='0'
    else:
        fid=re.match(r'support/payload/f(\d\d)/',rel).group(1);tgt=rel[len('support/payload/fNN/'):];when=str(int(fid));idn=str(int(fid))
    line=f'  <File target="{tgt}" source="{rel}" sha256="{h}" when="{when}" id="{idn}" />\n'
    anc=re.search(r'  <File target="SAN14Mods/modules/CrashLog.ini"[^\n]*\n',m);m=m[:anc.end()]+line+m[anc.end():]
    print('추가 항목',tgt)
# (5) data/
vals={}
for rel,src,key in (('data/fixdata_original_101.s14',DATA+'/fixdata_original_101.s14','fix_original'),('data/fixdata_nostat_101.s14',DATA+'/fixdata_nostat_101.s14','fix_nostat'),
                    ('data/model101/KIDSSystemResource.rdb',DATA+'/model101/KIDSSystemResource.rdb','model_orig_KIDSSystemResource.rdb'),('data/screen101/ScreenLayout.rdb',DATA+'/screen101/ScreenLayout.rdb','screen_orig_ScreenLayout.rdb'),
                    ('data/prev101/KIDSSystemResource.rdb',PREV101+'/model101/KIDSSystemResource.rdb','prev_KIDSSystemResource.rdb'),('data/prev101/ScreenLayout.rdb',PREV101+'/screen101/ScreenLayout.rdb','prev_ScreenLayout.rdb')):
    data=open(src,'rb').read();h=sha(data);old=locate(rel)
    if not(old and shaf(old)==h):put_new(rel,data);replaced.append((rel,shaf(old) if old else '-',h))
    vals[key]=h
    if f'<Value name="{key}" ' not in m:   # R43: 새 Value(옛 판 원본 색인) — 이름 순 자리에
        names=re.findall(r'  <Value name="([^"]+)"',m);after=[k for k in names if k>key]
        pos=m.index(f'  <Value name="{after[0]}"') if after else m.index('</Manifest>');m=m[:pos]+f'  <Value name="{key}" value="{h}" />\n'+m[pos:]
    m2=re.sub(r'(<Value name="%s" value=")[0-9a-f]{64}(")'%re.escape(key),r'\g<1>%s\2'%h,m);assert m2!=m or f'value="{h}"' in m,key;m=m2
# (6) 설치기 소스
for fn in ('Core.cs','Spec.cs','Stat.cs','Engine.cs','Update.cs','App.cs','BuildAndRun.ps1'):   # R43.28: Update.cs(깃허브 새 판 받기)
    rel='support/installer101/'+fn;data=open(R+'/installer101/'+fn,'rb').read();old=locate(rel)
    if not(old and shaf(old)==sha(data)):put_new(rel,data);replaced.append((rel,shaf(old) if old else '-',sha(data)))
# 정식판 뒤(11-08): 9번 확인 모듈 등록 이름 변경(14번보다 먼저 올라오게). 자료(source)는 그대로, 설치 대상 이름만.
m=m.replace('<File target="SAN14Mods/modules/Traits9Check.ini" ','<File target="SAN14Mods/modules/Mod09_Traits9Check.ini" ')
assert 'target="SAN14Mods/modules/Mod09_Traits9Check.ini"' in m
# (7) manifest 머리
m=re.sub(r'<Manifest version="[^"]+" game="[0-9a-f]{64}">',f'<Manifest version="{VER}" game="{NEWGAME_SHA}">',m)
# R43 시험판 이전 빌드의 해시(설치기가 '알 수 없는 내용'으로 막지 않게) — overlay_r43_prev_hashes.txt 에 빌드마다 누적
PREVH=os.path.join(R,'overlay_r43_prev_hashes.txt');cur_new={h for rel,oh,h in replaced}|{h for rel,h in added}
if os.path.exists(PREVH):
    for ln in open(PREVH,encoding='utf-8'):
        ln=ln.strip()
        if not ln or ln.startswith('#'):continue
        h,note=ln.split('\t',1)
        if h not in cur_new and f'sha256="{h}"' not in m:known_add.append((h,note))
# Known(예전 해시) — 정렬 자리에
for h,note in known_add:
    if f'<Known sha256="{h}"' in m:continue
    known=re.findall(r'  <Known sha256="([0-9a-f]{64})"',m);after=[k for k in known if k>h]
    pos=m.index(f'  <Known sha256="{after[0]}"') if after else m.index('</Manifest>');m=m[:pos]+f'  <Known sha256="{h}" note="{note}" />\n'+m[pos:]
mb=m.encode('utf-8');put_new('support/manifest101.xml',mb)
put_new('support/installer101/ManifestHash.cs',('namespace San14Patch101 { public static class ManifestHash { public const string Value="%s"; } }\n'%sha(mb)).encode('utf-8'))
# README
rd=open(PREV[0]+'/README_KO.txt','rb').read().decode('utf-8-sig')
note=('■ R43.44 (11월 20일): [오류 수정] 설치기 — 예전 판이 깔았던 파일(예: 0001_KO/msgdata_exce.bin)을 그 뒤 게임 업데이트·Steam 무결성 확인·다른 프로그램이 바꿔 두면 [설치]·[제거]가 "제거할 파일이 이 패치가 아닌 다른 프로그램에 의해 바뀌어 있습니다" 로 멈추던 것 고침 — 그 파일은 손대지 않고 설치 기록에서만 빼고 계속(설치기 기록에 한 줄). 게임 모듈 DLL 은 그대로.\n\n'
      '■ R43.43 (11월 17일): [오류 수정] 4번 연출 생략 — 도시 증축 같은 큰 결과 창에서 [확인]을 누를 때 단추 효과음이 창이 닫히며 잘려 나던 "툭" 소리를 없앰. 그 결과 창(게임 사건 결과 창)의 [확인]만 소리 없이, 다른 단추 소리는 그대로. SceneSkip.ini ResultClickMute=0 이면 예전처럼. [진단] 종합 진단 창 — 설치기 창이 열린 채 게임을 켜면 설치기가 3초마다 적용확인.log 를 막고 읽는 순간과 겹친 모듈의 시작 줄이 빠져 "로드는 됐는데 이번 실행 시작 기록이 없음"이 헛경보로 뜨던 것 고침(설치기는 쓰기를 막지 않고 읽음, 진단은 시작 줄이 없어도 이번 실행에 그 모듈 후크가 걸린 기록이 있으면 시작으로 봄). [설치기] 통합패치 폴더가 깊은 곳에 있으면 [업데이트]가 받는 중 임시 파일 경로 260자 한도에 걸려 멈추던 것 — 긴 경로 처리를 켜고, 그래도 못 쓰는 PC 는 받기 전에 막고 C:\\통합패치 처럼 짧은 곳으로 옮기라고 안내(다시 깔 필요 없음). 설치기 기록에 "긴 경로 지원: 됨/안 됨" 한 줄.\n\n'
      '■ R43.42 (11월 17일): [오류 수정] 9번 개성 9칸(13번도 같은 파일) — 9번을 켜면 지역상세(지역 정보) 화면 오른쪽이 통째로 비던 것 고침(9칸 화면 부품의 아는 화면 표 7번 칸이 옛 판 지역상세 함수표 그대로라 업데이트판 지역상세를 못 알아보고 그리기를 막았음 → 실행 때 새 함수표로 바로잡음, 9칸도 붙음). 9번 오류창에 다른 화면(일기토) 기록이 잘못 붙던 것 고침. [진단] 5·6번 통합편의 확인 실패 + 계절 맵이 실려 있으면 "다른 모드와 충돌 — 계절 맵"과 순서 안내(계절 맵이 먼저 걸린 경우, 계절 맵 새 판에서 해결).\n\n'
      '■ R43.41 (11월 16일): [프레임 개선] 34번 지역담당관 공석 경고 — 공석 판정을 이름판마다(0.15초마다 판 하나에 게임 함수 3~4개) 하지 않고 지금 보이는 지역마다 0.1초에 한 번만 해서 표로 나눠 씀, 거점 판의 지역은 한 번만 구해 기억, 돌려쓴 판에 남은 빨강은 우리가 칠한 글자판 목록으로 찾아 글자색 읽기를 거의 없앰(멈춤 때 판정 일 약 1/6, 지도 이동 때 색 읽기 약 1/25). 빨강이 뜨는 조건·때는 그대로. [진단] 종합 진단 창 — 5·6번 통합편의 호환 검사 실패인데 바꾼 자리 주인을 못 찾고 AI 모드(행동교정)가 실려 있으면 "다른 모드와 충돌 — AI 모드"로 이름을 붙이고 5·6번만 원래대로 둔 것(나머지 정상)이라고 안내.\n\n'
      '■ R43.40 (11월 15일): [오류 수정] 13번 논공 개성 가챠 — 위 줄 개성 해금을 하나 뽑은 뒤 두 번째 개성 해금 칸이 회색으로 꺼져 아래 줄을 골라야만 [결정]이 눌리던 것 고침. 원작 [결정] 판정과 같은 칸 수(랭크로 열린 칸 − 고른 칸)로 위 다음 칸을 켬. 계산 근거 칸에 열린 칸·고른 칸 표시, 그래도 꺼지면 이유를 13번 기록에 한 줄.\n'
      '■ R43.39 (11월 15일): [오류 수정] 20번 글씨체 — 예전에 지운 다른 글꼴 모드의 파일(0002/RRPreview.rdb.bin99)이 남아 있으면 "다른 패치의 파일이 같은 자리에 있습니다"로 설치가 막히던 것 고침(게임이 안 읽는 그 파일을 백업하고 설치, 20번을 빼면 되돌림. \'백업 후 그래도 설치\'도 이 파일까지 백업). 처음_설치: 풀기 전에 경로 길이 확인, 파일이 막히면 몇 번 다시 시도하고 백신 안내.\n'
      '■ R43.38 (11월 14일): 【중요】 2번 "턴 종료 자동 논공" 기능 삭제 — 고쳐도 버그가 계속 나와서 통합패치에서 뺌. 자동 포상·명승 투자·자동인사(자동 탐색)·13번 논공 가챠는 그대로. 논공은 논공 화면에서 직접. 게임 안 모드 설정 창의 자동 논공 줄 없앰, 13번↔2번 충돌 알림창 없앰, 설치기 상태 창 "2번 자동논공 요약" 없앰. [갱신] 때 옛 SAN14_AutoMerit.dll 을 지움. 업데이트 뒤 새 설치기가 큰 빨간 글씨 창으로 알림. 34번 지역담당관 공석 경고 프레임 개선(P255 — 지도 이동·확대 때 이름판마다 메모리 확인 7번·빨강 다시 칠하기 → 판이 정말 바뀔 때만, 한 프레임 판정 한도 64판, 기능은 그대로).\n\n'
      '■ R43.37 (11월 13일): 설치기 상태 창(2번 칸)에 "2번 자동논공 요약" — 이번 게임 실행에서 자동논공이 몇 번 불렸는지, 새 엔진/예전 방식 어느 길로 갔는지, 무엇을 줬는지, 건너뛴 무장과 이유, 통합편의 자동논공 설정, 13번·AI 모드(논공 기능 켬 여부)가 깔렸는지. 새 창은 없음. 게임 기능은 R43.36과 같음.\n\n'
      '■ R43.36 (11월 13일): 2번 자동논공으로 받은 내정 보상이 세이브를 불러오면 사라지던 것 진짜 원인 고침 — 게임 세이브는 보상을 3칸(병력 먼저)만 저장하는데 자동논공이 3칸 넘게 줬음. 이제 자동논공 보상을 처음부터 3칸 안으로(이미 가진 칸 그대로, 남은 칸에 새 내정 먼저) 맞춰 세이브 전후가 같음.\n\n'
      '■ R43.35 (11월 12일): 2번 자동논공 "reason=12 ic_plan_target_invalid" 창 고침 — 이미 받은 보상보다 작은 목표는 지금 수 그대로 저장, 계급 목표 값으로는 막지 않음, 보상 수가 이상한 무장·정보가 이상한 무장만 빼고 나머지는 저장.\n\n'
      '■ R43.34 (11월 12일): 2번 자동논공이 "reason=13 ic_plan_mixed_forces" 창과 함께 예전 방식으로 가던 것 고침 — 통합편의 계획에 세력이 다른 무장이 섞여 오면 세력별로 나눠 그 세력 군주 이름으로 저장.\n\n'
      '■ R43.33 (11월 12일): 2번 자동논공이 늘 예전 방식으로 가서 세이브를 불러오면 담당(내정 보상)이 사라지던 것 고침 — 새 엔진의 \'게임 창 스레드에서만\' 검사가 잘못돼(이 게임은 창과 게임 처리가 따로) 한 번도 못 돌았음. 이제 손 논공과 같은 방식으로 저장.\n\n'
      '■ R43.32 (11월 11일): 백신이 설치 자료의 튕김 기록기(SAN14_CrashLog.dll)를 지웠어도 설치 전체가 막히지 않음 — 그것만 빼고 설치(게임 폴더에 있던 것은 그대로). 우리 DLL 25개에 버전 정보(만든 곳·이름·설명)를 넣어 백신 오진을 줄임(코드는 그대로).\n\n'
      '■ R43.31 (11월 11일): [업데이트]·[버전 되돌리기]가 새 폴더를 만들지 않고 지금 폴더에 그대로 덮어씀(다 받고 지문 확인이 끝난 뒤에만, 실패하면 원래대로 되돌림). 처음 설치도 판 번호 없는 \'통합패치\' 폴더.\n\n'
      '■ R43.30 (11월 11일): [업데이트]·[버전 되돌리기] 때 진행 창(받기→확인→새 폴더→완료 단계, 막대·%, 지금 하는 일, 남은 시간, 취소). 끝나면 바로 새 판 설치기가 열림.\n\n'
      '■ R43.29 (11월 11일): 게임 안 종합 진단 창에 "설치한 통합패치 판"을 적음(제보 글자만으로 판을 알게). R43.28 설치 기록을 진단이 못 읽어 안 깐 번호의 옛 파일까지 문제로 세던 것 고침. 설치기 오른쪽 "게임 적용 확인" 칸이 게임 폴더를 읽은 뒤에도 "먼저 확인"으로 남던 것 고침.\n\n'
      '■ R43.28 (11월 11일): 설치기에 [업데이트]·[버전 되돌리기]·[게임 폴더 변경] 버튼, 상태 줄(설치판·공개 최신판·게임 켜짐), 탭별 깔린 수, 업데이트·작업 기록 탭.\n'
      '    - 새 판은 깃허브(github.com/wprkfdid12-ux/san14ce-integrated-patch)에서 받습니다. 바뀐 파일만 받고 나머지는 지금 폴더에서 복사해 옆에 새 폴더를 만듭니다. 지금 폴더·게임은 그대로.\n'
      '    - 게임 기능은 27차와 같습니다.\n\n'
      '■ R43 (11월 7일 최종판): 게임 2026-11-05 공식 업데이트판 전용. 옛 판(1.0.1, 9월 2일 빌드)에서는 "판이 다릅니다" 창과 함께 아무것도 안 바꿈.\n'
      '    - 모든 모듈의 게임 주소·자료 위치를 새 판에 맞춤(통합편의 포함). 24번 능력치 미적용 자료·10번/31번 그래픽 자료는 새 원본 위에 다시 만듦. 11번 3D 조형 런타임 새로 빌드, 13번 논공 개성 리졸버 번역.\n'
      '    - 문전박대: 군주가 관문·항구에 있어도 그곳을 가진 도시 기준으로 사신을 막음.\n'
      '    - 고침: 사실무장 편집을 열 때 튕김, 27번 미니맵이 안 그려지던 것, 22번 내정 계산 상수, 통합편의 포로 처우·탐색 예산 수치.\n'
      '    - 14번 전법 설명: 콜라보·특수 전법 48개 설명 추가, "총명강의" 글자 고침.\n'
      '    - 10번·31번: 옛 판 설치기가 1.0.1 원본으로 되돌려 둔 색인 레코드(KIDSSystemResource 1개·ScreenLayout 8개)를 새 판 원본으로 바로잡음(다른 모드가 고친 레코드는 그대로).\n'
      '    - 진단: 시작 30초·90초에 모듈이 다 올라왔는지 확인(SAN14_Diag), 문제가 있을 때만 창(R43D). 모듈이 못 돌 때는 어디가 왜 다른지 창(R43F).\n'
      '    - 알려진 한계: 17번 능력치 200 의 경험치 성장 분기 1곳은 새 판 코드에 자리가 모자라 적용하지 않음(게임 로그에 XP_GROWTH_NOT_APPLIED 한 줄). 나머지 9곳은 적용.\n'
      '    - 27번 안의 옛 실험 기능(FEED90, 미니맵과 별개)은 새 판에 옮기지 않고 돌지 않게 막아 둠.\n')
put_new('README_KO.txt',b'\xef\xbb\xbf'+(note+rd).encode('utf-8'))
put_new(f'README_덮어쓰기_{VER}.txt',b'\xef\xbb\xbf'+(f'통합패치 {VER} 덮어쓰기 — 게임 2026-11-05 업데이트판 전용 (11월 5일 최종판 폴더 위에 덮어쓰기)\r\n\r\n'
 '1. 이 ZIP(들) 안의 폴더·파일을 "통합패치 11월 5일 최종판" 폴더에 그대로 덮어쓰기(분할 ZIP 은 전부).\r\n'
 '2. 설치.cmd 실행 → 켜 둔 항목대로 게임 폴더에 깔림. 옛 게임판이면 설치기가 판이 다르다고 알려 주고 멈춤.\r\n\r\n'
 '확인 기록(SAN14_기록\\적용확인.log):\r\n'
 '  R43F 줄 = 어떤 모듈이 어디서 왜 못 돌았는지(창도 뜸)   R43D 줄 = 30초·90초 종합 진단   R43E 줄 = 판 불일치\r\n').encode('utf-8'))
# ---- 누적: manifest 의 모든 파일을 찾아, 정식판과 다르거나 없는 것만 ZIP 에
final_sums={}
for l in open(PREV[0]+'/SHA256SUMS.txt',encoding='utf-8'):   # 11월5일 최종판 목록(= overlay_r42i4 의 SHA256SUMS, PC 와 같음 확인)
    l=l.rstrip('\n')
    if l.strip():h_,p_=l.split('  ',1);final_sums[p_]=h_
missing=[];bad=[];cum={}
for src,s in re.findall(r'source="([^"]+)" sha256="([0-9a-f]{64})"',m):
    p=locate(src)
    if not p:
        if final_sums.get(src)==s:continue
        missing.append(src);continue
    if shaf(p)!=s:bad.append((src,shaf(p)[:12],s[:12]));continue
    if final_sums.get(src)!=s:cum[src]=p
assert not missing,missing;assert not bad,bad
for rel in ['support/manifest101.xml','support/installer101/ManifestHash.cs','README_KO.txt',f'README_덮어쓰기_{VER}.txt']+[r for r,_,_ in replaced if r.startswith(('data/','support/installer101/'))]:cum[rel]=NEW+'/'+rel
for rel,p in cum.items():
    d=PKG+'/'+rel;os.makedirs(os.path.dirname(d),exist_ok=True);shutil.copy(p,d)
# data Values == 실제 파일
for key,h in vals.items():
    rel={'fix_original':'data/fixdata_original_101.s14','fix_nostat':'data/fixdata_nostat_101.s14','model_orig_KIDSSystemResource.rdb':'data/model101/KIDSSystemResource.rdb','screen_orig_ScreenLayout.rdb':'data/screen101/ScreenLayout.rdb','prev_KIDSSystemResource.rdb':'data/prev101/KIDSSystemResource.rdb','prev_ScreenLayout.rdb':'data/prev101/ScreenLayout.rdb'}[key]
    assert shaf(locate(rel))==h,(key,rel)
# SHA256SUMS: 정식판 목록 + 바뀐 것
sums=dict(final_sums)
for rel in [r for r in REMOVED if '/f02/' in r]:sums.pop(rel,None)   # R43.38(P254): 지운 자동논공 파일은 목록에서도 뺌 → 업데이트(Update.Swap)가 받는 사람 폴더의 옛 사본을 지움
for rel in cum:sums[rel]=shaf(PKG+'/'+rel)
open(PKG+'/SHA256SUMS.txt','w',encoding='utf-8',newline='\n').write(''.join(f'{sums[p]}  {p}\n' for p in sorted(sums)))
# ---- 검사: 모듈 DLL(SAN14_ModInitV1 내보냄) 마다 같은 항목에 [Mod] File= 등록 ini
import xml.etree.ElementTree as ET;root=ET.fromstring(mb)
files=[(f.get('target'),f.get('source'),f.get('when')) for f in root.iter('File')]
def exports(p):
    o=subprocess.run(['llvm-readobj','--coff-exports',p],capture_output=True,text=True).stdout
    return set(re.findall(r'Name: (\S+)',o))
reg={}
for tgt,src,when in files:
    if tgt.lower().endswith('.ini') and 'modules/' in tgt:
        t=open(locate(src),'rb').read().decode('utf-8-sig','replace')
        if re.search(r'^\[Mod\]',t,re.M):
            fm=re.search(r'^File=(.+?)\s*$',t,re.M);en=re.search(r'^Enabled=1\s*$',t,re.M);ab=re.search(r'^CoreABI=65536\s*$',t,re.M)
            if fm and en and ab:reg.setdefault(when,set()).add(fm.group(1).strip().replace('\\','/').lower())
problems=[];OTHER_LOADER={'san14_modpackbridge.dll','san14_fps120.dll'}   # 19번 본체는 SAN14_FPS120Late.dll(등록됨)이 싣는다(2026-11-10 P201)
for tgt,src,when in files:
    if not tgt.lower().endswith('.dll') or '/' in tgt.replace('\\','/'):continue
    if tgt.lower() in OTHER_LOADER:continue
    p=locate(src)
    if not p or 'SAN14_ModInitV1' not in exports(p):continue
    ok=set(reg.get('base',set()))
    for w in when.split('|'):ok|=reg.get(w,set())
    ok|=reg.get(when,set())
    if tgt.lower() not in ok:problems.append((when,tgt))
print('모듈 등록 누락:',problems if problems else '없음');assert not problems,problems
# 옛 게임 해시가 설치기 소스 밖에 남아 있으면 안 됨(설치기 Spec 의 OldGames 는 예외)
for rel in cum:
    if rel.endswith(('.dll','.exe','.xml')):
        b=open(PKG+'/'+rel,'rb').read()
        for enc in(OLDGAME_SHA.encode(),bytes.fromhex(OLDGAME_SHA)):
            if enc in b and 'manifest' not in rel:print('주의: 옛 게임 해시 포함',rel)
# ---- 분할 ZIP(각각 독립, 용량 균등)
items=sorted(((os.path.getsize(PKG+'/'+rel),rel) for rel in cum),reverse=True)
parts=[];
for size,rel in items:
    for p in parts:
        if p[0]+size<=PART_MAX:p[0]+=size;p[1].append(rel);break
    else:parts.append([size,[rel]])
# SHA256SUMS·README·manifest 는 1부에
for must in ('SHA256SUMS.txt','README_KO.txt',f'README_덮어쓰기_{VER}.txt','support/manifest101.xml','support/installer101/ManifestHash.cs'):
    for p in parts:
        if must in p[1]:p[1].remove(must)
    parts[0][1].append(must)
N=len(parts);zips=[]
for i,(sz,rels) in enumerate(parts,1):
    zp=OUT+f'/통합패치_{VER}_덮어쓰기_{i}of{N}.zip'
    with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
        for rel in sorted(set(rels)):z.write(PKG+'/'+rel,rel)
        if 'SHA256SUMS.txt' not in rels:z.write(PKG+'/SHA256SUMS.txt','SHA256SUMS.txt')
    zips.append((zp,os.path.getsize(zp)))
print('누적 파일',len(cum));print('교체',len(replaced),'추가',len(added))
for r,o,h in replaced:print('  ',r,o[:12],'→',h[:12])
print('manifest',sha(mb)[:16],'game',NEWGAME_SHA[:16])
with open(PREVH,'a',encoding='utf-8') as f:
    f.write('# '+time.strftime('%Y-%m-%d %H:%M')+' R43 빌드\n')
    for rel,oh,h in replaced:
        if rel.startswith('support/payload/'):f.write(f'{h}\tR43 시험 이전판 {os.path.basename(rel)}\n')
    for rel,h in added:
        if rel.startswith('support/payload/'):f.write(f'{h}\tR43 시험 이전판 {os.path.basename(rel)}\n')
print('zips',[(os.path.basename(z),s) for z,s in zips])
