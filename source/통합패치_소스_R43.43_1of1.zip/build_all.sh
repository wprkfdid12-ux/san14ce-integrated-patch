#!/bin/bash
# R40 전체 재빌드: r40/src → r40/build_out (최종 패키지 전 반드시 실행)
set -e
B=/home/claude/r41/build_tc; S=/home/claude/r41/src; O=/home/claude/r41/build_out; mkdir -p $O
CXXF="--target=x86_64-w64-windows-gnu -O2 -std=c++17 -ffreestanding -nostdlibinc -I$B/inc -I$S -fno-exceptions -fno-rtti -fasynchronous-unwind-tables -fno-threadsafe-statics -fno-stack-protector -Wall -Wextra -Werror -Wno-cast-function-type -Wno-misleading-indentation -Wno-unused-parameter -Wno-missing-field-initializers -Wno-unused-function"
LDF="--target=x86_64-w64-windows-gnu -shared -fuse-ld=lld -nostdlib -Wl,--entry,DllMain -Wl,--dynamicbase,--nxcompat,--no-insert-timestamp,--high-entropy-va -L$B/lib"
clang --target=x86_64-w64-windows-gnu -O2 -fasynchronous-unwind-tables -ffreestanding -fno-builtin -nostdlibinc -c $B/src/crt_min.c -o $O/crt_min.o
clang --target=x86_64-w64-windows-gnu -c $B/src/chkstk.S -o $O/chkstk.o
# R43.32(P248, 11-11): 모든 DLL 에 버전 정보(만든 곳·이름·설명) — 버전 정보 없는 작은 DLL 을 백신이 바이러스로 잘못 잡는 일을 줄임.
#  판 번호는 넣지 않음(판마다 바뀌면 코드가 그대로인 DLL 까지 매번 새 파일이 됨). 글자는 영문(llvm-rc 코드 페이지 문제 피함).
verres() {   # $1=DLL 이름 → $O/<이름>.res
  local n=$1 stem=${1%.dll}
  cat > $O/$stem.rc <<RC
1 VERSIONINFO
FILEVERSION 43,0,0,0
PRODUCTVERSION 43,0,0,0
FILEFLAGSMASK 0x3f
FILEFLAGS 0x0
FILEOS 0x40004
FILETYPE 0x2
FILESUBTYPE 0x0
BEGIN
  BLOCK "StringFileInfo"
  BEGIN
    BLOCK "040904b0"
    BEGIN
      VALUE "CompanyName", "SAN14CE Integrated Patch (github.com/wprkfdid12-ux/san14ce-integrated-patch)"
      VALUE "FileDescription", "Romance of the Three Kingdoms XIV CE mod module ($stem)"
      VALUE "FileVersion", "43.0.0.0"
      VALUE "InternalName", "$stem"
      VALUE "LegalCopyright", "Free fan mod. Source code: github.com/wprkfdid12-ux/san14ce-integrated-patch"
      VALUE "OriginalFilename", "$n"
      VALUE "ProductName", "SAN14CE Integrated Patch"
      VALUE "ProductVersion", "R43"
    END
  END
  BLOCK "VarFileInfo"
  BEGIN
    VALUE "Translation", 0x409, 1200
  END
END
RC
  llvm-rc /nologo /fo $O/$stem.res $O/$stem.rc
}
build() {
  local name=$1; shift; local defs=""; local objs=()
  if [ -n "$ONLY" ] && [ "$ONLY" != "$name" ]; then return 0; fi   # ONLY=이름.dll 이면 그것만
  if [[ "$1" == -D* ]]; then defs=$1; shift; fi
  for f in "$@"; do
    local o=$O/${name}_$(basename $f).o
    case $f in
      *.S) clang --target=x86_64-w64-windows-gnu -I$S -c $S/$f -o $o ;;
      *) clang++ $CXXF $defs -c $S/$f -o $o ;;
    esac
    objs+=($o)
  done
  verres $name
  clang $LDF "${objs[@]}" $O/${name%.dll}.res $O/crt_min.o $O/chkstk.o -lkernel32 -lbcrypt -luser32 -o $O/$name
  sha256sum $O/$name
}
build SAN14_Patch27.dll patch27.cpp patch27_bridge.S patch27_ui.cpp officer_names.cpp death_log.cpp city_event_skip.cpp
build SAN14_DomesticTalent.dll domestic_talent.cpp
build SAN14_AutoPersonnelRepair.dll auto_personnel_repair.cpp
build SAN14_PrisonerReturn.dll prisoner_return.cpp prisoner_bridge.S
build SAN14_SettingsHelpScenic.dll settings_help.cpp
build SAN14_SettingsHelpScenic_domestic.dll -DSAN14_DOMESTIC_UI_BRIDGE settings_help.cpp
build SAN14_PatchTester.dll patch_tester.cpp
# R39 새 모듈
build SAN14_HiredFace.dll hired_face.cpp hired_face_bridge.S
build SAN14_ModSettings.dll mod_settings.cpp mod_settings_bridge.S
[ -z "$SKIP_B" ] && [ -f $S/status_color.cpp ] && build SAN14_StatusColor.dll status_color.cpp status_color_bridge.S || true
[ -z "$SKIP_B" ] && [ -f $S/region_officer.cpp ] && build SAN14_RegionOfficer.dll region_officer.cpp $( [ -f $S/region_officer_bridge.S ] && echo region_officer_bridge.S ) || true
[ -f $S/range.cpp ] && build SAN14_Range.dll range.cpp $( [ -f $S/range_bridge.S ] && echo range_bridge.S ) || true
build SAN14_ICGuard.dll ic_guard.cpp
build SAN14_Notice.dll notice.cpp
build SAN14_ItemPicture.dll item_picture.cpp item_picture_bridge.S   # R41e A8
build SAN14_SceneSkip.dll scene_skip.cpp scene_skip_bridge.S scene_skip_b23.cpp scene_skip_b23_bridge.S   # R42 B1~B3 4번 연출 생략
build SAN14_ExecuteLock.dll execute_lock.cpp execute_lock_bridge.S   # R42 B4 처단불가 시 처단 버튼 회색
build SAN14_Traits9Check.dll traits9_check.cpp   # R42 A10 개성 9칸 확인(읽기만)
build SAN14_DomesticAI.dll domestic_ai.cpp domestic_ai_bridge.S   # R42g 22번 AI 내정 순환(군주 반영)
build SAN14_DomesticPlayer.dll domestic_player.cpp   # R42h 22번 플레이어 내정 자동(DomesticCE 대체)
# R43.38(P254): 2번 자동논공 새 엔진(SAN14_AutoMerit.dll, auto_merit.cpp) 삭제 — 자동 논공 기능을 통합패치에서 뺌
build SAN14_Diag.dll diag.cpp   # R43 종합 진단(시작 30·90초, 읽기만)
build SAN14_Stats200New.dll stats200_new.cpp stats200_new_bridge.S   # R43 17번 능력치 200: 새 판 전용 소스 모듈(옛 이식본 대체)
# R43 시험13: 튕김 기록기 CrashLog R3 (C, 따로 만든 kernel32 가져오기 목록)
if [ -z "$ONLY" ] || [ "$ONLY" = "SAN14_CrashLog.dll" ]; then
 llvm-dlltool -m i386:x86-64 -d $S/crash_log_k32.def -l $O/libk32_crash.a
 clang --target=x86_64-w64-windows-gnu -O2 -ffreestanding -fno-builtin -fno-stack-protector -Wall -Wextra -Werror -c $S/crash_log.c -o $O/crash_log.o
 verres SAN14_CrashLog.dll
 clang --target=x86_64-w64-windows-gnu -fuse-ld=lld -nostdlib -shared -Wl,-e,DllMain -Wl,--no-insert-timestamp -s -o $O/SAN14_CrashLog.dll $O/crash_log.o $O/SAN14_CrashLog.res $O/chkstk.o $O/libk32_crash.a
 sha256sum $O/SAN14_CrashLog.dll
fi
# 2026-11-10 P201: 19번 본체(바이너리)를 통합편의 확인 뒤에 싣는 시작 지연 부품
build SAN14_FPS120Late.dll fps120_late.cpp fps120_late_bridge.S   # R43.43 P264: 일기토 밖 장면당 시간 = 실제 걸린 시간
