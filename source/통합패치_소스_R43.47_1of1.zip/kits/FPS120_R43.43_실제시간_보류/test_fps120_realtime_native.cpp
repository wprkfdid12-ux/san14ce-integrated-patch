// P264(2026-11-17 제보, 간간이 같은 말): 19번 120프레임을 깔면 컷신 일러스트 등 게임이 너무 느림 — 19번을 지우면 해결. 사용자 PC(늘 117~120)는 문제없음.
//  원인: 엔진은 장면 하나마다 (1/상한)초씩 게임 시간을 흘린다. 본체가 상한 120 과 함께 장면당 시간을 1/120, 연출 진행을 장면당 8ms 로 고정
//        → 1초에 120장을 못 그리는 PC 는 게임 시간이 그만큼 느림(60장이면 반속).
//  고침(R43.43, src/fps120_late.cpp + src/fps120_late_bridge.S): 일기토 밖 장면당 시간 = 실제 걸린 시간(1/120~1/60, 짧은 평균), 연출 ms 도 따라감. 일기토는 1/60·16ms 그대로.
//  이 시험: 실제 소스(Fps120Step·Fps120Dir·realtime_on·다리 asm)를 가짜 게임 이미지로 돌려
//   ① 60·75·90·120 프레임에서 게임 시간이 실제 시간과 같게 흐르는지 ② 50 프레임(60 아래)은 순정과 같은지 ③ 연출 ms ④ 일기토 동안 값·평균이 안 바뀌는지
//   ⑤ 튀는 프레임·같은 시각·시계 없음 ⑥ 본체 다리 돌리기(성공·거절 6가지) ⑦ 다리 asm 이 레지스터를 살리고 값을 제자리에 쓰는지.
//  빌드/실행: clang++ -std=c++17 -O1 -DS14_TEST_SHIM -Wno-everything -I test/shim27 -I src test/test_fps120_realtime_native.cpp src/fps120_late_bridge.S -o /tmp/t && /tmp/t
//   고치기 전(R43.42 까지 = 본체 다리 그대로: 설정값 1/120 · 8ms): -DOLD_SRC → ①③ 실패
#include <string>
#include <vector>
#include <cstdio>
#include <cstring>
#include <cmath>
#include "windows.h"
extern "C"{HMODULE LoadLibraryExW(const wchar_t*,HANDLE,DWORD);BOOL VirtualProtect(void*,SIZE_T,DWORD,DWORD*);BOOL FlushInstructionCache(HANDLE,const void*,SIZE_T);HANDLE GetCurrentProcess();}
#ifndef OLD_SRC
#include "../src/fps120_late.cpp"
#else
// 고치기 전: 본체 다리(SAN14_FPS120.dll 0x180001010 · 0x1800024b0)와 같은 셈 — 일기토 1/60·16ms, 그 밖 설정값·8ms
#include "common.h"
#define S14_MSABI __attribute__((ms_abi))
static U8*game;static const S14_CoreAPI*core;
static bool in_duel(){U8*m=*reinterpret_cast<U8**>(game+0x2786780);return m&&*reinterpret_cast<U8**>(m)==game+0x13b9058&&at<U32>(m,0x588)==1;}
extern "C" S14_MSABI U32 Fps120Step(U8*,U32 cfg){return in_duel()?0x3c888889:cfg;}
typedef int (S14_MSABI*DirAdvance)(void*,long long,long long);
extern "C" S14_MSABI int Fps120Dir(void*ctl){return (*reinterpret_cast<DirAdvance**>(ctl))[3](ctl,in_duel()?16:8,0);}
#endif
static std::string nar(const wchar_t*w){std::string s;for(;*w;w++)s+=(char)(*w<128?*w:'_');for(auto&c:s)if(c=='\\')c='/';return s;}
static U8*img;alignas(16) static U8 fpsmod[0x1000];static U8 other_mod[0x100];
extern "C" DWORD GetModuleFileNameW(HMODULE,wchar_t*o,DWORD cap){const char*p="C:\\G\\SAN14CE_KO.exe";DWORD n=0;for(;p[n]&&n+1<cap;n++)o[n]=p[n];o[n]=0;return n;}
static unsigned long long now_ms=1000;extern "C" ULONGLONG GetTickCount64(void){return now_ms;}extern "C" void Sleep(DWORD ms){now_ms+=ms;}
extern "C" DWORD GetFileAttributesW(const wchar_t*){return 0xffffffffu;}   // 통합편의 없음
extern "C" unsigned GetPrivateProfileIntW(const wchar_t*,const wchar_t*,int,const wchar_t*){return 0;}
extern "C" HMODULE GetModuleHandleW(const wchar_t*){return nullptr;}
static int init_calls;
static void body_site(U32 site,U32 len,U32 relay_off,U8*dest){U8*r=img+relay_off;r[0]=0xff;r[1]=0x25;memset(r+2,0,4);memcpy(r+6,&dest,8);
 img[site]=0xe8;I32 d=(I32)(relay_off-(site+5));memcpy(img+site+1,&d,4);memset(img+site+5,0x90,len-5);}
static int fake_init(const S14_CoreAPI*){init_calls++;img[0x44df40]=0xe8;LONG v=0x00123456;memcpy(img+0x44df41,&v,4);body_site(0xf416ad,7,0x1000000,fpsmod+0x100);body_site(0x36dd05,11,0x1001000,fpsmod+0x200);return 1;}
extern "C" void*GetProcAddress(HMODULE m,const char*n){if(m==(HMODULE)fpsmod)return strcmp(n,"SAN14_ModInitV1")?nullptr:(void*)fake_init;return nullptr;}
extern "C" HMODULE LoadLibraryExW(const wchar_t*p,HANDLE,DWORD){return nar(p).find("SAN14_FPS120.dll")!=std::string::npos?(HMODULE)fpsmod:nullptr;}
static bool vp_fail;extern "C" BOOL VirtualProtect(void*,SIZE_T,DWORD,DWORD*o){if(o)*o=0x20;return vp_fail?0:1;}
extern "C" BOOL FlushInstructionCache(HANDLE,const void*,SIZE_T){return 1;}
extern "C" HANDLE GetCurrentProcess(){return nullptr;}
extern "C" HANDLE CreateThread(void*,SIZE_T,LPTHREAD_START_ROUTINE,LPVOID,DWORD,LPDWORD){return (HANDLE)1;}
extern "C" BOOL CloseHandle(HANDLE){return 1;}
static std::vector<std::string> logs;static void lg(const char*s){logs.push_back(s);}
static bool has(const char*s){for(auto&l:logs)if(l.find(s)!=std::string::npos)return true;return false;}
static std::vector<std::string> written;
extern "C" BOOL CreateDirectoryW(const wchar_t*,void*){return 1;}
extern "C" HANDLE CreateFileW(const wchar_t*,DWORD,DWORD,void*,DWORD,DWORD,void*){return (HANDLE)2;}
extern "C" BOOL WriteFile(HANDLE,const void*b,DWORD n,DWORD*w,void*){written.push_back(std::string((const char*)b,n));if(w)*w=n;return 1;}
extern "C" void GetLocalTime(SYSTEMTIME*t){memset(t,0,sizeof *t);}
extern "C" int MessageBoxW(void*,const wchar_t*,const wchar_t*,unsigned){return 0;}
static bool failed(const char*sub=""){for(auto&l:written)if(l.find("R43F")!=std::string::npos&&l.find(sub)!=std::string::npos)return true;return false;}
static int fails;static void check(bool c,const char*m){printf("%s %s\n",c?"  ok  ":"  FAIL",m);if(!c)fails++;}
static int rd(const void*,uintptr_t){return 1;}
static int relays_made;static bool relay_null;
static U8*mr(const void*,const void*dest){if(relay_null)return nullptr;U8*r=img+0x1100000+0x1000*(relays_made++);r[0]=0xff;r[1]=0x25;memset(r+2,0,4);memcpy(r+6,&dest,8);return r;}
static void fr(void*){}static I32 ih(const char*,const S14_Hook*,U32){return 1;}
static S14_Resolved res;static S14_CoreAPI api;
// ---- 가짜 엔진 상태: 프레임 시계(r15), 엔진 시계 전역(진동수 10MHz), 일기토 관리자
alignas(16) static U8 clk[0x40];alignas(16) static U8 cg[0x40];alignas(16) static U8 mgr[0x600];
static const unsigned long long F=10000000ull;static unsigned long long tnow=1000000000ull;
static void duel(bool on){at<U8*>(img,0x2786780)=on?mgr:nullptr;at<U8*>(mgr,0)=img+0x13b9058;at<U32>(mgr,0x588)=1;}
static float bitsf(U32 u){float f;memcpy(&f,&u,4);return f;}
static U32 frame(double sec){unsigned long long t=(unsigned long long)llround(sec*F);at<unsigned long long>(clk,8)=tnow;tnow+=t;at<unsigned long long>(clk,0)=tnow;return Fps120Step(clk,0x3c088889);}
// fps 로 n 프레임(상한 120: 프레임 간격은 1/120 보다 짧을 수 없음). 앞 warm 프레임 뒤의 게임 시간 ÷ 실제 시간
static double run(double fps,int n,int warm=120){double g=0,r=0;double iv=1.0/fps;if(iv<1.0/120)iv=1.0/120;for(int i=0;i<n;i++){U32 b=frame(iv);if(i>=warm){g+=bitsf(b);r+=iv;}}return g/r;}
static long long got_ms=-1,got_r8=-1;static void*got_this;
static int S14_MSABI adv(void*t,long long ms,long long r8){got_this=t;got_ms=ms;got_r8=r8;return 7;}
static void*vt[4]={nullptr,nullptr,nullptr,(void*)adv};static void*ctl[1]={vt};
static long long dir_ms(){got_ms=-1;int r=Fps120Dir(ctl);return (r==7&&got_this==ctl&&got_r8==0)?got_ms:-99;}
extern "C" void call_bridge(void*cfg,void*clock,unsigned long long*out);
asm(R"(
.text
.globl call_bridge
call_bridge:
 push %rbx
 push %rbp
 push %r12
 push %r13
 push %r14
 push %r15
 sub $8,%rsp
 mov %rdx,%r12
 mov %rdi,%rax
 mov %rsi,%r15
 movabs $0x1111111111111111,%rcx
 movabs $0x2222222222222222,%rdx
 movabs $0x8888888888888888,%r8
 movabs $0x9999999999999999,%r9
 movabs $0xaaaaaaaaaaaaaaaa,%r10
 movabs $0xbbbbbbbbbbbbbbbb,%r11
 movabs $0x3333333333333333,%rbx
 movabs $0x5555555555555555,%rbp
 movabs $0xdddddddddddddddd,%r13
 movabs $0xeeeeeeeeeeeeeeee,%r14
 movabs $0x7777777777777777,%rdi
 movabs $0x6666666666666666,%rsi
 movq %rcx,%xmm0
 movq %rdx,%xmm1
 movq %r8,%xmm2
 movq %r9,%xmm3
 movq %r10,%xmm4
 movq %r11,%xmm5
 mov %rsp,160(%r12)
 call Fps120StepBridge
 mov %rcx,0(%r12)
 mov %rdx,8(%r12)
 mov %r8,16(%r12)
 mov %r9,24(%r12)
 mov %r10,32(%r12)
 mov %r11,40(%r12)
 mov %rbx,48(%r12)
 mov %rbp,56(%r12)
 mov %r13,64(%r12)
 mov %r14,72(%r12)
 mov %rdi,80(%r12)
 mov %rsi,88(%r12)
 mov %r15,96(%r12)
 movq %xmm0,104(%r12)
 movq %xmm1,112(%r12)
 movq %xmm2,120(%r12)
 movq %xmm3,128(%r12)
 movq %xmm4,136(%r12)
 movq %xmm5,144(%r12)
 mov %rsp,152(%r12)
 add $8,%rsp
 pop %r15
 pop %r14
 pop %r13
 pop %r12
 pop %rbp
 pop %rbx
 ret
)");
static bool regs_kept(const unsigned long long*o,void*clock){
 static const unsigned long long want[12]={0x1111111111111111ull,0x2222222222222222ull,0x8888888888888888ull,0x9999999999999999ull,0xaaaaaaaaaaaaaaaaull,0xbbbbbbbbbbbbbbbbull,0x3333333333333333ull,0x5555555555555555ull,0xddddddddddddddddull,0xeeeeeeeeeeeeeeeeull,0x7777777777777777ull,0x6666666666666666ull};
 for(int i=0;i<12;i++)if(o[i]!=want[i])return false;
 if(o[12]!=(unsigned long long)clock)return false;
 static const int xi[6]={0,1,2,3,4,5};for(int k=0;k<6;k++)if(o[13+k]!=want[xi[k]])return false;
 return o[19]==o[20]&&(o[20]&15)==0;   // rsp 그대로, 부르기 전 16 정렬(다리 안 C 함수도 정렬됨)
}
static bool site_to(U32 site,void*dest){U8*p=img+site;if(p[0]!=0xe8)return false;LONG d;memcpy(&d,p+1,4);U8*t=p+5+d;if(t[0]!=0xff||t[1]!=0x25)return false;void*to;memcpy(&to,t+6,8);return to==dest;}
int main(){
 img=(U8*)calloc(0x2a02000,1);game=img;
 fpsmod[0]='M';fpsmod[1]='Z';at<U32>(fpsmod,0x3c)=0x80;at<U32>(fpsmod,0x80)=0x4550;at<U32>(fpsmod,0x80+0x50)=0x1000;
 res.size=sizeof res;res.abi=S14_ABI;res.image_size=S14_GAME_IMAGE;res.image=img;
 api.size=sizeof api;api.abi=S14_ABI;api.resolved=&res;api.Readable=rd;api.InstallHooks=ih;api.MakeRelay=mr;api.FreeRelay=fr;api.Log=lg;core=&api;
 at<U8*>(img,0x27df6f0)=cg;at<unsigned long long>(cg,0x18)=F;duel(false);
 printf("[1] 게임 시간 ÷ 실제 시간 (1.000 이면 정상 속도) — 고치기 전은 120 프레임 아래에서 느려짐\n");
 {double r120=run(120,1200);char m[160];snprintf(m,sizeof m,"120 프레임: %.4f (지금과 같음)",r120);check(fabs(r120-1)<0.005,m);
  U32 b=frame(1.0/120);snprintf(m,sizeof m,"120 프레임 장면당 시간 비트 = 0x%08x (예전 고정값 0x3c088889 그대로)",b);check(b==0x3c088889,m);
  double r90=run(90,1200);snprintf(m,sizeof m,"90 프레임: %.4f",r90);check(fabs(r90-1)<0.005,m);
  double r75=run(75,1200);snprintf(m,sizeof m,"75 프레임: %.4f",r75);check(fabs(r75-1)<0.005,m);
  double r60=run(60,1200);snprintf(m,sizeof m,"60 프레임: %.4f (고치기 전 0.5)",r60);check(fabs(r60-1)<0.005,m);
  double r50=run(50,1200);snprintf(m,sizeof m,"50 프레임(60 아래): %.4f = 순정과 같음(50/60=0.8333)",r50);check(fabs(r50-50.0/60)<0.005,m);
  run(120,600);
#if S14_DIAG_RECORDS && !defined(OLD_SRC)
  check(has("FPS120Late R43.43 self-check (first 60 s outside duels): frames="),"확인판: 일기토 밖 60초 뒤 자가진단 한 줄(runtime.log)");
#endif
 }
 printf("[2] 연출 진행 ms (순정 셈: 장면당 시간 x1000 버림 — 1/60 → 16, 1/120 → 8)\n");
 {run(120,600);long long a=dir_ms();run(90,600);long long b=dir_ms();run(60,600);long long c=dir_ms();char m[120];
  snprintf(m,sizeof m,"120→%lld  90→%lld  60→%lld (기대 8·11·16)",a,b,c);check(a==8&&b==11&&c==16,m);run(120,600);}
 printf("[3] 일기토: 본체와 같은 1/60·16ms, 일기토 동안은 평균에 안 넣음\n");
 {run(120,600);duel(true);bool all=true;for(int i=0;i<600;i++)if(frame(1.0/60)!=0x3c888889)all=false;check(all,"일기토 600 프레임 내내 장면당 시간 = 0x3c888889(1/60)");
  check(dir_ms()==16,"일기토 연출 16ms");duel(false);U32 b=frame(1.0/120);check(b==0x3c088889,"일기토 끝난 첫 프레임: 일기토 전 값(1/120) 그대로 — 일기토 60 상한을 '느린 PC'로 잘못 보지 않음");
  check(dir_ms()==8,"일기토 끝 연출 8ms");
  at<U8*>(img,0x2786780)=mgr;at<U32>(mgr,0x588)=0;U32 c=frame(1.0/120);check(c==0x3c088889&&dir_ms()==8,"일기토 관리자는 있으나 일기토 아님(+0x588=0) → 일기토로 안 봄");
  at<U32>(mgr,0x588)=1;at<U8*>(mgr,0)=img+0x13b9000;c=frame(1.0/120);check(c==0x3c088889,"함수표가 다른 물체 → 일기토로 안 봄");duel(false);}
 printf("[4] 튀는 프레임·흔들림·이상한 시계\n");
 {run(120,600);U32 b=frame(0.5);check(bitsf(b)<=1.0f/60+1e-7f,"0.5초 걸린 프레임(로딩 끊김) → 1/60 넘지 않음");
  int k=0;for(;k<200;k++){U32 c=frame(1.0/120);if(bitsf(c)<1.01f/120)break;}char m[100];snprintf(m,sizeof m,"끊김 뒤 %d 프레임 만에 1/120 의 1%% 안으로 복귀(평균이 짧음)",k);check(k<40,m);
  double g=0,r=0;bool in=true;for(int i=0;i<2000;i++){double iv=(i&1)?0.0091:0.0084;U32 c=frame(iv);float f=bitsf(c);if(f<1.0f/120-1e-7f||f>1.0f/60+1e-7f)in=false;if(i>=200){g+=f;r+=iv;}}
  snprintf(m,sizeof m,"8.4/9.1ms 번갈아(흔들림): 게임/실제 %.4f, 값은 늘 1/120~1/60",g/r);check(in&&fabs(g/r-1)<0.005,m);
  run(120,600);at<unsigned long long>(clk,8)=tnow;at<unsigned long long>(clk,0)=tnow;U32 s=Fps120Step(clk,0x3c088889);check(s==0x3c088889,"같은 시각 두 번(간격 0) → 나눗셈 없이 직전 값");
  at<U8*>(img,0x27df6f0)=nullptr;s=Fps120Step(clk,0x12345678);check(s==0x12345678,"엔진 시계 전역 없음 → 설정값 그대로(본체와 같음)");at<U8*>(img,0x27df6f0)=cg;
  at<unsigned long long>(cg,0x18)=0;s=frame(1.0/60);check(s==0x3c088889,"시계 진동수 0 → 나눗셈 없이 직전 값");at<unsigned long long>(cg,0x18)=F;run(120,600);}
#ifndef OLD_SRC
 printf("[5] 본체 다리 돌리기(realtime_on)\n");
 auto setup=[&](){memset(img+0xf416ad,0,16);memset(img+0x36dd05,0,16);body_site(0xf416ad,7,0x1000000,fpsmod+0x100);body_site(0x36dd05,11,0x1001000,fpsmod+0x200);
  written.clear();logs.clear();relays_made=0;relay_null=false;vp_fail=false;rt_on=0;};
 {setup();realtime_on((HMODULE)fpsmod);check(site_to(0xf416ad,(void*)&Fps120StepBridge)&&site_to(0x36dd05,(void*)&Fps120Dir),"두 자리 call 이 우리 다리로(장면당 시간 → Fps120StepBridge, 연출 → Fps120Dir)");
  bool shape=true;for(int i=5;i<7;i++)if(img[0xf416ad+i]!=0x90)shape=false;for(int i=5;i<11;i++)if(img[0x36dd05+i]!=0x90)shape=false;check(shape,"자리 길이·nop 그대로(call 대상 4바이트만 바뀜)");
  check(rt_on==1&&has("real-time step on")&&!failed(),"켜짐 기록, 오류 없음");}
 {setup();memcpy(img+0xf416ad,kStepNative,7);memcpy(img+0x36dd05,kDirNative,11);U8 a[7],b[11];memcpy(a,img+0xf416ad,7);memcpy(b,img+0x36dd05,11);realtime_on((HMODULE)fpsmod);
  check(!memcmp(a,img+0xf416ad,7)&&!memcmp(b,img+0x36dd05,11)&&rt_on==0&&failed("not patched"),"본체가 안 고친 자리(원래 바이트) → 안 건드림 + 오류 기록");}
 {setup();body_site(0xf416ad,7,0x1000000,other_mod);U8 a[7],b[11];memcpy(a,img+0xf416ad,7);memcpy(b,img+0x36dd05,11);realtime_on((HMODULE)fpsmod);
  check(!memcmp(a,img+0xf416ad,7)&&!memcmp(b,img+0x36dd05,11)&&failed("not a ModCore relay"),"call 대상이 본체 밖(다른 모드) → 둘 다 안 건드림 + 오류 기록");}
 {setup();img[0x36dd05+7]=0xcc;U8 a[7],b[11];memcpy(a,img+0xf416ad,7);memcpy(b,img+0x36dd05,11);realtime_on((HMODULE)fpsmod);
  check(!memcmp(a,img+0xf416ad,7)&&!memcmp(b,img+0x36dd05,11)&&failed("direction call")&&rt_on==0,"연출 자리 모양 다름 → 먼저 돌린 장면당 시간도 본체 다리로 되돌림(둘이 다른 셈 안 쓰게)");}
 {setup();U8 a[7];memcpy(a,img+0xf416ad,7);relay_null=true;realtime_on((HMODULE)fpsmod);check(!memcmp(a,img+0xf416ad,7)&&failed("relay alloc"),"ModCore 다리 못 만듦 → 안 건드림 + 오류 기록");}
 {setup();U8 a[7];memcpy(a,img+0xf416ad,7);fpsmod[0]='X';realtime_on((HMODULE)fpsmod);fpsmod[0]='M';check(!memcmp(a,img+0xf416ad,7)&&failed("body_range"),"본체 PE 머리 못 읽음 → 안 건드림 + 오류 기록");}
 {setup();U8 a[7];memcpy(a,img+0xf416ad,7);vp_fail=true;realtime_on((HMODULE)fpsmod);vp_fail=false;check(!memcmp(a,img+0xf416ad,7)&&failed("write failed"),"쓰기 권한 실패 → 그대로 + 오류 기록");}
 printf("[6] 시작 전체(SAN14_ModInitV1): 본체 시작 → 바로 두 자리 돌림(통합편의 확인 구간 밖이라 기다리지 않음)\n");
 {memcpy(img+0x44df40,kDuelNative,5);memcpy(img+0xf416ad,kStepNative,7);memcpy(img+0x36dd05,kDirNative,11);written.clear();logs.clear();relays_made=0;rt_on=0;
  int r=SAN14_ModInitV1(&api);check(r==1&&init_calls==1&&site_to(0xf416ad,(void*)&Fps120StepBridge)&&site_to(0x36dd05,(void*)&Fps120Dir)&&rt_on==1&&!failed(),"본체 시작 OK, 두 자리 우리 다리, 오류 없음");}
 printf("[7] 다리 asm(Fps120StepBridge): 설정 [rax+0x34]·시계 r15 를 넘기고 결과를 [r15+0x18]에, 레지스터는 그대로\n");
 {alignas(16) static U8 cfg[0x40];unsigned long long o[24];
  duel(true);at<U32>(cfg,0x34)=0x3c088889;at<U32>(clk,0x18)=0;call_bridge(cfg,clk,o);check(at<U32>(clk,0x18)==0x3c888889&&regs_kept(o,clk),"일기토 → [r15+0x18]=1/60, 휘발·비휘발 레지스터·xmm0~5·rsp 그대로");duel(false);
  at<U8*>(img,0x27df6f0)=nullptr;at<U32>(cfg,0x34)=0x12345678;call_bridge(cfg,clk,o);check(at<U32>(clk,0x18)==0x12345678&&regs_kept(o,clk),"시계 없음 → 설정 [rax+0x34] 값이 그대로 들어감(edx 로 넘김 확인)");at<U8*>(img,0x27df6f0)=cg;
  rt_avg=1.0/120;at<unsigned long long>(clk,8)=tnow;tnow+=F/60;at<unsigned long long>(clk,0)=tnow;call_bridge(cfg,clk,o);
  float want=(float)(1.0/120+((double)(F/60)/(double)F-1.0/120)*0.125);U32 wb;memcpy(&wb,&want,4);check(at<U32>(clk,0x18)==wb&&regs_kept(o,clk),"실제 간격 1/60 한 프레임 → 평균 1/8 만큼 다가간 값(시계 r15 → rcx 확인)");}
#endif
 printf(fails?"\n실패 %d\n":"\n전부 통과\n",fails);return fails?1:0;
}
