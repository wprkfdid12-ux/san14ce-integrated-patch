// 19번 120프레임 — 장면당 시간 다리 (R43.43, P264). src/fps120_late.cpp 의 realtime_on 이 본체 다리 대신 이리로 돌림.
//  게임 자리 exe+0xf416ad (원래 `mov eax,[rax+0x34] ; mov [r15+0x18],eax`, 본체가 `call 다리 ; nop nop` 으로 바꿔 둔 7바이트)에서 call 로 들어옴.
//  들어올 때: rax = 고정 간격 설정 객체(널 아님 — 엔진이 0xf41660 에서 확인한 뒤의 길), r15 = 프레임 시계([+0] 지금 · [+8] 앞 프레임 · [+0x18] 장면당 시간).
//  게임 함수의 rsp 는 16 정렬(0xf41370: push 8개 + sub 0x68) → call 뒤 들어올 때 8 어긋남 → sub 0xd8 로 다시 16 정렬(본체 다리와 같은 틀).
//  C 함수(Fps120Step) 앞뒤로 휘발 레지스터 rcx·rdx·r8~r11·xmm0~5 를 그대로 되살린다(rax 는 뒤에서 안 씀 — 0xf416b4 부터 다시 채움, 본체도 안 살림).
// .seh_* 는 윈도 되감기 정보(튕김 기록 스택 추적용). 리눅스 시험 빌드(test_fps120_realtime)에서는 빠짐.
.text
.globl Fps120StepBridge
Fps120StepBridge:
#ifdef _WIN32
.seh_proc Fps120StepBridge
#endif
 sub $0xd8,%rsp
#ifdef _WIN32
.seh_stackalloc 0xd8
#endif
#ifdef _WIN32
.seh_endprologue
#endif
 mov %rcx,0x20(%rsp)
 mov %rdx,0x28(%rsp)
 mov %r8,0x30(%rsp)
 mov %r9,0x38(%rsp)
 mov %r10,0x40(%rsp)
 mov %r11,0x48(%rsp)
 movdqu %xmm0,0x50(%rsp)
 movdqu %xmm1,0x60(%rsp)
 movdqu %xmm2,0x70(%rsp)
 movdqu %xmm3,0x80(%rsp)
 movdqu %xmm4,0x90(%rsp)
 movdqu %xmm5,0xa0(%rsp)
 mov 0x34(%rax),%edx
 mov %r15,%rcx
 call Fps120Step
 mov %eax,0x18(%r15)
 movdqu 0x50(%rsp),%xmm0
 movdqu 0x60(%rsp),%xmm1
 movdqu 0x70(%rsp),%xmm2
 movdqu 0x80(%rsp),%xmm3
 movdqu 0x90(%rsp),%xmm4
 movdqu 0xa0(%rsp),%xmm5
 mov 0x20(%rsp),%rcx
 mov 0x28(%rsp),%rdx
 mov 0x30(%rsp),%r8
 mov 0x38(%rsp),%r9
 mov 0x40(%rsp),%r10
 mov 0x48(%rsp),%r11
 add $0xd8,%rsp
 ret
#ifdef _WIN32
.seh_endproc
#endif
