# 통합패치 소스

삼국지14 CE 통합패치를 만드는 소스 전부입니다.

- `src/` — 게임에 들어가는 DLL 소스(C/C++)
- `installer101/` — 설치기(C#, PC에서 .NET Framework csc 로 컴파일)
- `test/` — 오프라인 시험(`test/run_offline_all.sh`)
- `교훈_점검/` — 작업 기록·관문 검사
- `build_all.sh` — DLL 빌드, `build_overlay_r43.py` — 배포 꾸러미, `make_release_r43.py` — 업데이트 파일

게임 원본 자료와 빌드 결과물(DLL·EXE)은 넣지 않았습니다. 빌드에 쓰는 윈도 가져오기 라이브러리(build_tc/lib/*.a)는 들어 있습니다.

빌드: clang(x86_64-w64-windows-gnu)으로 `bash build_all.sh`. 소스가 없는 DLL(교훈_점검/05_소스장부.tsv 의 '바이너리' 줄)은 깃허브 updates 의 기본판·판 파일 안에 완성본이 있습니다.

AI 모드 호환판 자료는 개인용이라 넣지 않았습니다.
