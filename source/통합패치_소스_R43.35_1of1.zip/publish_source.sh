#!/bin/bash
# 사용자 11-11: 통합패치 소스를 깃허브 저장소 source/ 폴더에 공개.
#   bash publish_source.sh [저장소 폴더]   → 저장소/source/통합패치_소스_<판>_1of1.zip 하나로(사용자 11-11 'zip로 올려'; 옛 소스 ZIP은 지움, 커밋·올리기는 따로)
# 빼는 것: 남의 AI 모드 호환 자료(ai_compat·aiinst — 개인용), 게임 원본에서 나온 자료(.s14·.rdb 등),
#          빌드 결과물·실행 파일(dll·exe·o·obj·pyc·리눅스 시험 실행 파일). 윈도 가져오기 라이브러리(.a, build_tc/lib 등)는 넣음 — 없으면 DLL 을 다시 빌드 못 함(사용자 11-11 '깃허브만으로 복구'), 배포 꾸러미(overlay_*·final_r43·release·newpkg 꾸러미)
set -e
REPO=${1:-/home/claude/san14ce-integrated-patch}; R=/home/claude/r41
[ -d "$REPO/.git" ] || { echo "저장소 폴더가 아님: $REPO"; exit 1; }
PAN=$(grep -o 'Version="R[0-9.]*"' "$R/installer101/Spec.cs" | cut -d'"' -f2); [ -n "$PAN" ] || { echo "판 번호 못 읽음"; exit 1; }
REAL_REPO=$REPO; REPO=$(mktemp -d); mkdir -p "$REPO/source"
cd "$R"
find . -type f \
 -not -path './ai_compat/*' -not -path './aiinst/*' -not -path './newpkg/payload_*' -not -path './field_out_*' -not -path './build_out/*' \
 -not -path './overlay_*' -not -path './final_r43/*' -not -path './release/*' -not -path './payload_r43/*' -not -path '*/__pycache__/*' \
 -not -path './test/th_sim/th_sim' -not -path './test/ai_defer/sim' -not -path './test/ai_defer/sim1514' \
 -not -regex '.*\.\(dll\|exe\|o\|obj\|pyd\|pyc\|bin\|rdb\|merged\|s14\|zip\|lib\|bak.*\)$' -print0 \
 | tar --null -cf - -T - | (cd "$REPO/source" && tar xf -)
# 남은 파일 중 바이너리가 있으면 멈춤(새로 생긴 실행 파일이 섞이지 않게)
BIN=$(cd "$REPO/source" && find . -type f -print0 | xargs -0 -I{} sh -c 'case "$1" in *.a) echo ok;; *) file -b --mime-encoding -- "$1";; esac' _ {} 2>/dev/null | grep -c '^binary$' || true)
[ "$BIN" = 0 ] || { echo "바이너리 $BIN 개 섞임 — 빼는 목록에 더할 것"; (cd "$REPO/source" && find . -type f ! -name '*.a' -exec sh -c '[ "$(file -b --mime-encoding "$1")" = binary ] && echo "$1"' _ {} \;); exit 1; }
# 개인 정보 검사(전자우편)
if grep -rIl -E '[A-Za-z0-9._%+-]+@(naver|gmail|daum|hanmail|kakao)\.' "$REPO/source" >/dev/null; then echo "전자우편 주소가 섞임"; grep -rIl -E '[A-Za-z0-9._%+-]+@(naver|gmail|daum|hanmail|kakao)\.' "$REPO/source"; exit 1; fi
cat > "$REPO/source/README_소스.md" <<'EOF'
# 통합패치 소스

삼국지14 CE 통합패치를 만드는 소스 전부입니다.

- `src/` — 게임에 들어가는 DLL 소스(C/C++)
- `installer101/` — 설치기(C#, PC에서 .NET Framework csc 로 컴파일)
- `test/` — 오프라인 시험(`test/run_offline_all.sh`)
- `교훈_점검/` — 작업 기록·관문 검사
- `build_all.sh` — DLL 빌드, `build_overlay_r43.py` — 배포 꾸러미, `make_release_r43.py` — 업데이트 파일

게임 원본 자료와 빌드 결과물(DLL·EXE)은 넣지 않았습니다. 빌드에 쓰는 윈도 가져오기 라이브러리(build_tc/lib/*.a)는 들어 있습니다.

빌드: clang(x86_64-w64-windows-gnu)으로 `bash build_all.sh`. 소스가 없는 DLL(교훈_점검/05_소스장부.tsv 의 '바이너리' 줄)은 깃허브 updates 의 기본판·판 파일 안에 완성본이 있습니다.

AI 모드 호환판 자료는 개인용이라 넣지 않았습니다.
EOF
N=$(cd "$REPO/source" && find . -type f | wc -l)
rm -rf "$REAL_REPO/source"; mkdir -p "$REAL_REPO/source"; Z="$REAL_REPO/source/통합패치_소스_${PAN}_1of1.zip"
# 한글 이름이 윈도 탐색기에서 안 깨지게 파이썬 zipfile 로(이름에 UTF-8 표시가 붙음)
python3 -c "
import zipfile,os,sys
src,z=sys.argv[1],sys.argv[2]
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as f:
    for d,_,fs in sorted(os.walk(src)):
        for n in sorted(fs):p=os.path.join(d,n);f.write(p,os.path.relpath(p,src))
" "$REPO/source" "$Z"; rm -rf "$REPO"
python3 -c "
import zipfile,sys;z=zipfile.ZipFile(sys.argv[1]);assert z.testzip() is None
bad=[i.filename for i in z.infolist() if any(ord(c)>127 for c in i.filename) and not i.flag_bits&0x800];assert not bad,bad[:3]" "$Z"
echo "$(basename "$Z") : $N 개, $(du -h "$Z" | cut -f1)"
