#!/bin/bash
# CRT-free clang build of SAN14_WheelRegion.dll (Linux or Windows with clang + lld).
#   ./build.sh            -> out/SAN14_WheelRegion.dll
# Regenerate the generated headers first if you changed their sources:
#   python3 tools/gen_block.py                 (src/wr_block.S  -> src/wr_block.h)
#   python3 tools/build_targets.py MapExCe.bin (map             -> src/wr_targets.h)
set -e
B=$(cd "$(dirname "$0")" && pwd)
O=$B/out; L=$O/lib
mkdir -p $O $L
for n in kernel32 user32; do llvm-dlltool -m i386:x86-64 -d $B/lib/$n.def -l $L/lib$n.a; done
CF="--target=x86_64-w64-windows-gnu -O2 -fasynchronous-unwind-tables -ffreestanding -fno-builtin -nostdlibinc -isystem $(clang -print-resource-dir)/include -fno-stack-protector -fno-stack-check -mno-stack-arg-probe -Wall -Wextra -Werror -Wno-unused-parameter"
for f in src/wheel_region.c dll/wr_dll.c dll/crt_min.c; do
  clang $CF -c $B/$f -o $O/$(basename $f .c).o
done
# R2 (통합패치 R43.48 P280): 버전 정보(만든 곳·이름·설명) — 통합패치 build_all.sh verres 와 같은 내용. 버전 정보 없는 작은 DLL 을 백신이 잘못 잡는 일을 줄임.
cat > $O/SAN14_WheelRegion.rc <<'RC'
1 VERSIONINFO
FILEVERSION 43,0,0,0
PRODUCTVERSION 43,0,0,0
FILEFLAGSMASK 0x3f
FILEFLAGS 0x0
FILEOS 0x40004
FILETYPE 0x2
FILESUBTYPE 0x0
BEGIN
  BLOCK "StringFileInfo"
  BEGIN
    BLOCK "040904b0"
    BEGIN
      VALUE "CompanyName", "SAN14CE Integrated Patch (github.com/wprkfdid12-ux/san14ce-integrated-patch)"
      VALUE "FileDescription", "Romance of the Three Kingdoms XIV CE mod module (SAN14_WheelRegion)"
      VALUE "FileVersion", "43.0.0.0"
      VALUE "InternalName", "SAN14_WheelRegion"
      VALUE "LegalCopyright", "Free fan mod. Source code: github.com/wprkfdid12-ux/san14ce-integrated-patch"
      VALUE "OriginalFilename", "SAN14_WheelRegion.dll"
      VALUE "ProductName", "SAN14CE Integrated Patch"
      VALUE "ProductVersion", "R43"
    END
  END
  BLOCK "VarFileInfo"
  BEGIN
    VALUE "Translation", 0x409, 1200
  END
END
RC
llvm-rc /nologo /fo $O/SAN14_WheelRegion.res $O/SAN14_WheelRegion.rc
clang --target=x86_64-w64-windows-gnu -shared -fuse-ld=lld -nostdlib \
  -Wl,--entry,DllMain -Wl,--dynamicbase,--nxcompat,--no-insert-timestamp,--high-entropy-va \
  $O/wheel_region.o $O/wr_dll.o $O/crt_min.o $O/SAN14_WheelRegion.res -L$L -lkernel32 -luser32 -o $O/SAN14_WheelRegion.dll
sha256sum $O/SAN14_WheelRegion.dll
