# 해제한 게임 exe(파일 모양)를 메모리 모양(이미지)으로 펼치고, host_test 에 줄 주소(RVA)를 찾는다.
#  사용: python3 -I make_image.py <해제본.exe> <나올 image.bin>   → 표준 출력에 RVA 9개(16진수, 공백 구분)
#  RVA: A B K map db CHexFocusModeHex_vt state_mgr CUserStrategyState_vt CUserStrategyLayout_vt
import struct, sys, re
exe, out = sys.argv[1], sys.argv[2]
d = open(exe, 'rb').read()
e = struct.unpack_from('<I', d, 0x3c)[0]; ns = struct.unpack_from('<H', d, e + 6)[0]; osz = struct.unpack_from('<H', d, e + 20)[0]
base = struct.unpack_from('<Q', d, e + 48)[0]; size = struct.unpack_from('<I', d, e + 24 + 56)[0]; hdr = struct.unpack_from('<I', d, e + 24 + 60)[0]
img = bytearray(size); img[:hdr] = d[:hdr]
for k in range(ns):
    nm, vs, va, rs, rp = struct.unpack_from('<8sIIII', d, e + 24 + osz + 40 * k)
    img[va:va + min(rs, vs if vs else rs)] = d[rp:rp + min(rs, vs if vs else rs)]
open(out, 'wb').write(img)
def find1(pat, mask):
    rx = b''.join(re.escape(bytes([c])) if m == 'x' else b'.' for c, m in zip(pat, mask))
    hits = [m.start() for m in re.finditer(rx, bytes(img), re.S)]
    assert len(hits) == 1, (pat[:6].hex(), len(hits)); return hits[0]
A = find1(bytes.fromhex('443B420475033 3C0C3448 90AB801000000448942 04C3'.replace(' ', '')), 'x' * 22)
pB = bytes.fromhex('448BF0488BCD4489B5B0F40200E8'); B = find1(pB, 'x' * 14) + 6
pK1 = bytes.fromhex('0FB6431083E80F83F80376 00 488BCBE8 00000000 FFC83DF3010000'.replace(' ', ''))
k1 = find1(pK1, 'xxxxxxxxxxx?xxxx????xxxxxxx') + 15; K = k1 + 5 + struct.unpack_from('<i', img, k1 + 1)[0]
pG = bytes.fromhex('488B05 00000000 48895C2420 4863 88B0F40200 81F90FBD0000 77 00 488B05 00000000 488B9CC870E20000'.replace(' ', ''))
g = find1(pG, 'xxx????xxxxxxxxxxxxxxxxxxx?xxx????xxxxxxxx')
MAP = g + 7 + struct.unpack_from('<i', img, g + 3)[0]; DB = g + 27 + 7 + struct.unpack_from('<i', img, g + 30)[0]
pSM = bytes.fromhex('E8 00000000 48837810 00 7508 33C0 4883C420 5BC3 488B5010 488B4820'.replace(' ', ''))
sm = find1(pSM, 'x????xxxxxxxxxxxxxxxxxxxxxxx'); f = sm + 5 + struct.unpack_from('<i', img, sm + 1)[0]
q = bytes(img[f:f + 0x90]).find(bytes.fromhex('488D05')); q = f + q
SM = q + 7 + struct.unpack_from('<i', img, q + 3)[0]
def vt(name):
    n = bytes(img).find(name.encode() + b'\0'); assert n > 0, name
    td = n - 0x10
    for m in re.finditer(re.escape(struct.pack('<I', td)), bytes(img)):
        col = m.start() - 12
        if struct.unpack_from('<II', img, col)[:2] == (1, 0):
            p = bytes(img).find(struct.pack('<Q', base + col))
            if p > 0: return p + 8
    raise SystemExit('vtable not found: ' + name)
print(' '.join('%x' % v for v in (A, B, K, MAP, DB, vt('.?AVCHexFocusModeHex@@'), SM, vt('.?AVCUserStrategyState@@'), vt('.?AVCUserStrategyLayout@@'))))
