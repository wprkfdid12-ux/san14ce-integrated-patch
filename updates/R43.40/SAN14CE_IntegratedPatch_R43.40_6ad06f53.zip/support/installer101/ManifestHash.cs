namespace San14Patch101 { public static class ManifestHash { public const string Value="ab39d886c791c079920ab95c75ef29093fe07ada8f5b4f4bc5f1855867e023e3"; } }
