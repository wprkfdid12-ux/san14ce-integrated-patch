namespace San14Patch101 { public static class ManifestHash { public const string Value="d41bb157fee0b560fe297c8a7ef7fd834a47ec9209f13cf0944567f021be7e85"; } }
