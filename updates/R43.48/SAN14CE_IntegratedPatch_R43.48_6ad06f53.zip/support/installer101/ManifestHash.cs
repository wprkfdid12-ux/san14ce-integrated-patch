namespace San14Patch101 { public static class ManifestHash { public const string Value="786a9144cf8140a39a4a987930c0d668217e56ce367284e6ae64bce2e26c0ff7"; } }
