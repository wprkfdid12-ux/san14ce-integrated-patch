namespace San14Patch101 { public static class ManifestHash { public const string Value="e00960a622b3fed75cd8e9646c545aa8b106be34460187eeb65b6e4993c53623"; } }
