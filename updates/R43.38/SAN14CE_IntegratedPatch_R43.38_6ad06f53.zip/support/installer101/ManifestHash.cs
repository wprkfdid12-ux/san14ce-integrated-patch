namespace San14Patch101 { public static class ManifestHash { public const string Value="de1ec3307d384378e36983ddb9da0efad9d03214097f682118d61f16d4a32b63"; } }
