namespace San14Patch101 { public static class ManifestHash { public const string Value="4d3c16ae1df533d481a85a4775596455a51248f60a15016a8c8efe38386e8a93"; } }
