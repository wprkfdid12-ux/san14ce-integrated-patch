namespace San14Patch101 { public static class ManifestHash { public const string Value="7650dbb746781c211b182ff7c1e599fc8a428f88f3b8b8e73208ab22a30d7067"; } }
