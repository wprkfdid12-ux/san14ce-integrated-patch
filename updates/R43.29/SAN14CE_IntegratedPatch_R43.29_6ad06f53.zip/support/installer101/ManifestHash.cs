namespace San14Patch101 { public static class ManifestHash { public const string Value="6a7211fcca03b3a88c98e080f05772e64eb27aee56e063d5ccb9072ef8a9c95d"; } }
