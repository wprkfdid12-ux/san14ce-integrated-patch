namespace San14Patch101 { public static class ManifestHash { public const string Value="0d2cad66bac2cb19b24725f3009e976ca8ff819e2ecfec9aa91d45ebee279f2f"; } }
