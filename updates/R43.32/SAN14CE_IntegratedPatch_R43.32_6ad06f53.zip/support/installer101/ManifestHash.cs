namespace San14Patch101 { public static class ManifestHash { public const string Value="71f4d0bdfeabcf1ea164328c17dd295df6486c74e7433097b4ea8d24ec604d87"; } }
