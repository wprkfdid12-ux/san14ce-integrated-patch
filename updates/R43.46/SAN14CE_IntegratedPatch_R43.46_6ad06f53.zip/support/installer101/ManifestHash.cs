namespace San14Patch101 { public static class ManifestHash { public const string Value="c9729e62fd3e436a7fc7900f12646bd59df3ae8dcd9687c723eb5e88081fca2b"; } }
