﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace San14Patch101 {
static class Program {
 [STAThread] static void Main(string[] args){
  bool first;using(var mutex=new Mutex(true,"Local\\SAN14CE_Patch101",out first)){
   if(!first){MessageBox.Show("이미 열려 있는 설치창을 종료한 뒤 다시 실행해 주세요.");return;}
   Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);
   try{Application.Run(new MainForm());}catch(Exception e){ErrorBox.Show(null,"설치기 실행",ErrorBox.Describe("설치기를 실행하는 중",null,e,"설치기 폴더(ZIP 을 푼 폴더)에 쓰기 권한이 있는지, 백신이 파일을 막지 않는지 확인한 뒤 다시 실행해 주세요."));}
  }
 }
}
// 글자를 복사할 수 있는 오류·안내 창 (카페 댓글용)
public static class ErrorBox {
 public static string Describe(string doing,string file,Exception e,string fix){
  var b=new StringBuilder();b.AppendLine("[통합패치 "+Spec.Version+" 설치기]");
  if(!String.IsNullOrEmpty(doing))b.AppendLine("무엇을 하다가: "+doing);
  if(!String.IsNullOrEmpty(file))b.AppendLine("어떤 파일: "+file);
  if(e!=null){b.AppendLine("오류: "+e.Message);if(e is UnauthorizedAccessException)fix=fix??"게임 폴더에 쓰기 권한이 없습니다. 설치.cmd 를 관리자 권한으로 실행하거나 게임 폴더 권한을 확인해 주세요.";else if(e is IOException&&e.Message.Contains("사용 중"))fix=fix??"게임·런처·다른 설치기를 모두 닫은 뒤 다시 눌러 주세요.";}
  if(!String.IsNullOrEmpty(fix))b.AppendLine("해결: "+fix);
  b.AppendLine();b.AppendLine("이 글자를 그대로 복사해 댓글로 알려 주시면 원인을 확인할 수 있습니다.");
  return b.ToString();
 }
 public static void Show(IWin32Window owner,string title,string text){
  using(var f=new Form{Text=title,ClientSize=new Size(720,360),StartPosition=FormStartPosition.CenterParent,MinimizeBox=false,MaximizeBox=false,ShowInTaskbar=false,Font=new Font("Malgun Gothic",10)}){
   var box=new TextBox{Multiline=true,ReadOnly=true,ScrollBars=ScrollBars.Vertical,Dock=DockStyle.Fill,Text=text,BackColor=SystemColors.Window};
   var panel=new FlowLayoutPanel{Dock=DockStyle.Bottom,Height=44,FlowDirection=FlowDirection.RightToLeft,Padding=new Padding(6)};
   var close=new Button{Text="닫기",AutoSize=true,Height=30};var copy=new Button{Text="이 내용 복사",AutoSize=true,Height=30};
   close.Click+=delegate{f.Close();};copy.Click+=delegate{try{Clipboard.SetText(text);copy.Text="복사했습니다";}catch(Exception){}};
   panel.Controls.Add(close);panel.Controls.Add(copy);f.Controls.Add(box);f.Controls.Add(panel);f.AcceptButton=close;
   if(owner!=null)f.ShowDialog(owner);else f.ShowDialog();
  }
 }
 // 선택지 버튼이 있는 물음 창: 누른 버튼 번호(0~), 창을 닫으면 -1
 public static int Ask(IWin32Window owner,string title,string text,string[] choices){
  int result=-1;
  using(var f=new Form{Text=title,ClientSize=new Size(640,260),StartPosition=FormStartPosition.CenterParent,MinimizeBox=false,MaximizeBox=false,ShowInTaskbar=false,Font=new Font("Malgun Gothic",10),FormBorderStyle=FormBorderStyle.FixedDialog}){
   var label=new Label{Text=text,Dock=DockStyle.Fill,Padding=new Padding(14),AutoSize=false};
   var panel=new FlowLayoutPanel{Dock=DockStyle.Bottom,Height=50,FlowDirection=FlowDirection.RightToLeft,Padding=new Padding(8)};
   for(int i=choices.Length-1;i>=0;i--){int k=i;var b=new Button{Text=choices[i],AutoSize=true,Height=32,Padding=new Padding(6,0,6,0)};b.Click+=delegate{result=k;f.Close();};panel.Controls.Add(b);}
   f.Controls.Add(label);f.Controls.Add(panel);
   if(owner!=null)f.ShowDialog(owner);else f.ShowDialog();
  }
  return result;
 }
}
public sealed class MainForm:Form {
 readonly string package=Spec.FindPackageRoot(AppDomain.CurrentDomain.BaseDirectory);
 readonly Manifest manifest;
 readonly TextBox target=new TextBox(),log=new TextBox(),desc=new TextBox(),detail=new TextBox();readonly DataGridView grid=new DataGridView();
 readonly Button browse=new Button(),refresh=new Button(),tabAll=new Button(),tabNone=new Button(),tabInstall=new Button(),tabRemove=new Button(),allSel=new Button(),allNone=new Button(),allInstall=new Button(),allRemove=new Button(),records=new Button(),openLog=new Button(),copyDetail=new Button();
 readonly Label summary=new Label(),tabLabel=new Label(),descTitle=new Label(),detailTitle=new Label();
 readonly TabControl tabs=new TabControl();
 bool busy,missNoted,modelNoted,copiesNoted;static List<string> otherCopies=new List<string>();State loaded;string loadedRoot="";Engine.AppliedInfo[] appliedInfo;
 int CurrentCat(){return tabs.SelectedIndex-1;} // -1 = 전체
 public MainForm(){
  manifest=Manifest.Load(Path.Combine(package,"support","manifest101.xml"),ManifestHash.Value);
  Text="삼국지14 CE 통합패치 "+Spec.Version+" (공식 "+Spec.GameLabel+" 전용)";
  Font=new Font("Malgun Gothic",10);ClientSize=new Size(1400,900);MinimumSize=new Size(1100,700);AutoScaleMode=AutoScaleMode.Font;StartPosition=FormStartPosition.CenterScreen;
  var layout=new TableLayoutPanel{Dock=DockStyle.Fill,Padding=new Padding(14),ColumnCount=2,RowCount=7};
  layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,64));layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,36));
  foreach(float h in new float[]{44,50,36,34})layout.RowStyles.Add(new RowStyle(SizeType.Absolute,h));
  layout.RowStyles.Add(new RowStyle(SizeType.Percent,100));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,46));layout.RowStyles.Add(new RowStyle(SizeType.Absolute,46));Controls.Add(layout);
  var title=new Label{Text="삼국지14 CE 통합패치 "+Spec.Version,Font=new Font(Font.FontFamily,19,FontStyle.Bold),Dock=DockStyle.Fill,AutoSize=false};layout.Controls.Add(title,0,0);layout.SetColumnSpan(title,2);
  var note=new Label{Text="체크 = 선택. [선택 설치]는 체크한 항목을 설치·갱신, [선택 제거]는 체크한 항목을 제거합니다. 항목을 누르면 오른쪽에 설명과 게임 적용 확인이 나옵니다. 탭은 분류일 뿐, 번호는 그대로입니다.",Dock=DockStyle.Fill};layout.Controls.Add(note,0,1);layout.SetColumnSpan(note,2);
  var pathPanel=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=3,RowCount=1,Margin=new Padding(0)};
  pathPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));pathPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,112));pathPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,116));
  target.Dock=DockStyle.Fill;browse.Text="게임 찾기";browse.Dock=DockStyle.Fill;refresh.Text="상태 새로고침";refresh.Dock=DockStyle.Fill;pathPanel.Controls.Add(target,0,0);pathPanel.Controls.Add(browse,1,0);pathPanel.Controls.Add(refresh,2,0);layout.Controls.Add(pathPanel,0,2);layout.SetColumnSpan(pathPanel,2);
  summary.Text="현재 상태: 아직 확인하지 않음";summary.Font=new Font(Font,FontStyle.Bold);summary.Dock=DockStyle.Fill;summary.TextAlign=ContentAlignment.MiddleLeft;layout.Controls.Add(summary,0,3);layout.SetColumnSpan(summary,2);
  // 왼쪽: 탭 + 표 + 기록
  var left=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=3,Margin=new Padding(0,0,8,0)};
  left.RowStyles.Add(new RowStyle(SizeType.Absolute,30));left.RowStyles.Add(new RowStyle(SizeType.Percent,100));left.RowStyles.Add(new RowStyle(SizeType.Absolute,84));
  tabs.Dock=DockStyle.Fill;tabs.SizeMode=TabSizeMode.Fixed;tabs.ItemSize=new Size(118,26);tabs.Appearance=TabAppearance.Normal;
  tabs.TabPages.Add(new TabPage("전체 "+Spec.Shown));
  for(int c=0;c<Spec.CategoryNames.Length;c++)tabs.TabPages.Add(new TabPage(Spec.CategoryNames[c]+" "+Spec.InCategory(c).Length));
  // 탭은 헤더만 쓰고 내용은 하나의 표를 필터
  var tabHost=new Panel{Dock=DockStyle.Fill,Margin=new Padding(0)};tabs.Height=30;tabs.Dock=DockStyle.Top;tabHost.Controls.Add(tabs);
  left.Controls.Add(tabHost,0,0);
  grid.Dock=DockStyle.Fill;grid.ScrollBars=ScrollBars.Both;grid.AllowUserToAddRows=false;grid.AllowUserToDeleteRows=false;grid.AllowUserToResizeRows=false;grid.RowHeadersVisible=false;grid.AutoGenerateColumns=false;grid.MultiSelect=false;grid.SelectionMode=DataGridViewSelectionMode.FullRowSelect;grid.RowTemplate.Height=28;grid.AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill;grid.BackgroundColor=SystemColors.Window;grid.BorderStyle=BorderStyle.FixedSingle;grid.ColumnHeadersHeightSizeMode=DataGridViewColumnHeadersHeightSizeMode.DisableResizing;grid.ColumnHeadersHeight=32;
  grid.Columns.Add(new DataGridViewCheckBoxColumn{Name="Wanted",HeaderText="설치",FillWeight=6,MinimumWidth=46,SortMode=DataGridViewColumnSortMode.NotSortable});
  grid.Columns.Add(new DataGridViewTextBoxColumn{Name="Number",HeaderText="번호",ReadOnly=true,FillWeight=5,MinimumWidth=46,SortMode=DataGridViewColumnSortMode.NotSortable});
  grid.Columns.Add(new DataGridViewTextBoxColumn{Name="Feature",HeaderText="패치 이름",ReadOnly=true,FillWeight=52,MinimumWidth=360,SortMode=DataGridViewColumnSortMode.NotSortable});
  grid.Columns.Add(new DataGridViewTextBoxColumn{Name="Current",HeaderText="현재 상태",ReadOnly=true,FillWeight=12,MinimumWidth=100,SortMode=DataGridViewColumnSortMode.NotSortable});
  grid.Columns.Add(new DataGridViewTextBoxColumn{Name="Applied",HeaderText="게임 적용 (마지막 실행)",ReadOnly=true,FillWeight=25,MinimumWidth=200,SortMode=DataGridViewColumnSortMode.NotSortable});
  for(int r=0;r<Spec.Count;r++){int id=Spec.IdAt(r);int index=grid.Rows.Add(false,Spec.Num(id),Spec.Names[id-1]+(id>=Spec.FirstNew?"  [NEW]":""),"미확인","");grid.Rows[index].Cells[2].ToolTipText=Spec.Details[id-1][0];if(id>=Spec.FirstNew)grid.Rows[index].DefaultCellStyle.BackColor=Color.FromArgb(255,248,220);}
  grid.Rows[Spec.RowOf(Spec.Fog)].Visible=false; // R41: 12번 삭제(빈 번호)
  grid.CurrentCellDirtyStateChanged+=delegate{if(grid.IsCurrentCellDirty)grid.CommitEdit(DataGridViewDataErrorContexts.Commit);};
  grid.SelectionChanged+=delegate{ShowDetail();};
  grid.CellClick+=delegate(object sender,DataGridViewCellEventArgs ev){if(ev.RowIndex>=0)ShowDetail();};
  left.Controls.Add(grid,0,1);
  log.Dock=DockStyle.Fill;log.Multiline=true;log.ReadOnly=true;log.ScrollBars=ScrollBars.Vertical;log.Font=new Font("Consolas",9);left.Controls.Add(log,0,2);
  layout.Controls.Add(left,0,4);
  // 오른쪽: 설명칸 + 게임 적용 확인
  var right=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=5,Margin=new Padding(0)};
  right.RowStyles.Add(new RowStyle(SizeType.Absolute,26));right.RowStyles.Add(new RowStyle(SizeType.Percent,52));right.RowStyles.Add(new RowStyle(SizeType.Absolute,26));right.RowStyles.Add(new RowStyle(SizeType.Percent,48));right.RowStyles.Add(new RowStyle(SizeType.Absolute,36));
  descTitle.Text="설명";descTitle.Font=new Font(Font,FontStyle.Bold);descTitle.Dock=DockStyle.Fill;descTitle.TextAlign=ContentAlignment.MiddleLeft;right.Controls.Add(descTitle,0,0);
  desc.Multiline=true;desc.ReadOnly=true;desc.ScrollBars=ScrollBars.Vertical;desc.Dock=DockStyle.Fill;desc.BackColor=Color.FromArgb(255,253,245);desc.Text="항목을 누르면 설명이 나옵니다.";right.Controls.Add(desc,0,1);
  detailTitle.Text="게임 적용 확인 (마지막 실행)";detailTitle.Font=new Font(Font,FontStyle.Bold);detailTitle.Dock=DockStyle.Fill;detailTitle.TextAlign=ContentAlignment.MiddleLeft;right.Controls.Add(detailTitle,0,2);
  detail.Multiline=true;detail.ReadOnly=true;detail.ScrollBars=ScrollBars.Vertical;detail.Dock=DockStyle.Fill;detail.BackColor=Color.FromArgb(243,251,251);right.Controls.Add(detail,0,3);
  var dbtn=new FlowLayoutPanel{Dock=DockStyle.Fill,FlowDirection=FlowDirection.LeftToRight,Margin=new Padding(0)};
  openLog.Text="기록 열기";copyDetail.Text="이 내용 복사";foreach(var b in new[]{openLog,copyDetail}){b.AutoSize=true;b.Height=28;dbtn.Controls.Add(b);}right.Controls.Add(dbtn,0,4);
  layout.Controls.Add(right,1,4);
  // 버튼 두 줄
  var row1=new FlowLayoutPanel{Dock=DockStyle.Fill,FlowDirection=FlowDirection.LeftToRight,WrapContents=false,Margin=new Padding(0,6,0,0)};
  tabLabel.Text="이 탭만:";tabLabel.Font=new Font(Font,FontStyle.Bold);tabLabel.AutoSize=false;tabLabel.Width=150;tabLabel.Height=32;tabLabel.TextAlign=ContentAlignment.MiddleLeft;row1.Controls.Add(tabLabel);
  tabAll.Text="이 탭 전체 선택";tabNone.Text="이 탭 전체 해제";tabInstall.Text="이 탭 선택 설치";tabRemove.Text="이 탭 선택 제거";
  foreach(var b in new[]{tabAll,tabNone,tabInstall,tabRemove}){b.AutoSize=true;b.Height=32;b.Padding=new Padding(8,0,8,0);row1.Controls.Add(b);}
  layout.Controls.Add(row1,0,5);layout.SetColumnSpan(row1,2);
  var row2=new FlowLayoutPanel{Dock=DockStyle.Fill,FlowDirection=FlowDirection.LeftToRight,WrapContents=false,Margin=new Padding(0)};
  var allLabel=new Label{Text="모든 탭:",Font=new Font(Font,FontStyle.Bold),AutoSize=false,Width=150,Height=32,TextAlign=ContentAlignment.MiddleLeft};row2.Controls.Add(allLabel);
  allSel.Text="전체 선택";allNone.Text="전체 해제";allInstall.Text="선택 설치";allRemove.Text="선택 제거";records.Text="기록 폴더 열기";
  foreach(var b in new[]{allSel,allNone,allInstall,allRemove,records}){b.AutoSize=true;b.Height=32;b.Padding=new Padding(8,0,8,0);row2.Controls.Add(b);}
  tabInstall.ForeColor=allInstall.ForeColor=Color.FromArgb(0,80,160);tabRemove.ForeColor=allRemove.ForeColor=Color.FromArgb(170,40,30);
  layout.Controls.Add(row2,0,6);layout.SetColumnSpan(row2,2);
  // 동작
  tabs.SelectedIndexChanged+=delegate{ApplyFilter();};
  browse.Click+=delegate{using(var f=new OpenFileDialog{Title="게임의 SAN14CE_KO.exe 선택",Filter="삼국지14 CE|SAN14CE_KO.exe",CheckFileExists=true})if(f.ShowDialog(this)==DialogResult.OK){target.Text=Path.GetDirectoryName(f.FileName);LoadState();}};
  refresh.Click+=delegate{LoadState();};target.Leave+=delegate{if(!String.Equals(CleanRoot(),loadedRoot,StringComparison.OrdinalIgnoreCase))LoadState();};
  tabAll.Click+=delegate{SetChecks(true,true);};tabNone.Click+=delegate{SetChecks(false,true);};allSel.Click+=delegate{SetChecks(true,false);};allNone.Click+=delegate{SetChecks(false,false);};
  tabInstall.Click+=delegate{Start(true,true);};tabRemove.Click+=delegate{Start(false,true);};allInstall.Click+=delegate{Start(true,false);};allRemove.Click+=delegate{Start(false,false);};
  records.Click+=delegate{OpenRecords();};openLog.Click+=delegate{OpenRecords();};
  copyDetail.Click+=delegate{try{Clipboard.SetText(detailTitle.Text+"\r\n"+detail.Text);}catch(Exception){}};
  FormClosing+=delegate(object sender,FormClosingEventArgs e){if(busy){e.Cancel=true;}};
  Shown+=delegate{var work=Screen.FromControl(this).WorkingArea;if(Height>work.Height)Height=work.Height;if(Width>work.Width)Width=work.Width;try{target.Text=Detect();LoadState();}catch(Exception e){WriteLog(e.Message);}};
  ApplyFilter();
 }
 string CleanRoot(){return target.Text.Trim().Trim('"');}
 Engine Make(){var e=new Engine(CleanRoot(),package,manifest);e.Log=WriteLog;return e;}
 void WriteLog(string text){if(InvokeRequired){BeginInvoke(new Action<string>(WriteLog),text);return;}if(log.TextLength>250000)log.Text=log.Text.Substring(log.TextLength-160000);log.AppendText("["+DateTime.Now.ToString("HH:mm:ss")+"] "+text+Environment.NewLine);}
 bool InTab(int id){if(Spec.Retired(id))return false;int c=CurrentCat();return c<0||Spec.Category(id)==c;}
 void ApplyFilter(){
  grid.CurrentCell=null;grid.ClearSelection();
  for(int r=0;r<Spec.Count;r++)grid.Rows[r].Visible=InTab(Spec.IdAt(r));
  int c=CurrentCat();tabLabel.Text=c<0?"이 탭(전체)만:":"이 탭("+Spec.CategoryNames[c]+")만:";
 }
 void SetChecks(bool on,bool tabOnly){for(int r=0;r<Spec.Count;r++)if(!tabOnly||InTab(Spec.IdAt(r)))grid.Rows[r].Cells[0].Value=on;}
 bool[] Selected(bool tabOnly){grid.EndEdit();var b=new bool[Spec.Count];for(int i=0;i<Spec.Count;i++){int id=i+1;b[i]=Convert.ToBoolean(grid.Rows[Spec.RowOf(id)].Cells[0].Value)&&(!tabOnly||InTab(id));}return b;}
 void ShowDetail(){
  if(grid.CurrentRow==null||grid.CurrentRow.Index<0){return;}
  int id=Spec.IdAt(grid.CurrentRow.Index);var d=Spec.Details[id-1];
  descTitle.Text=id+"번 "+Spec.Names[id-1]+(id>=Spec.FirstNew?"  [NEW]":"");
  desc.Text="■ 무엇을 하나\r\n"+d[0]+"\r\n\r\n■ 켜면 이렇게 됩니다\r\n"+d[1]+"\r\n\r\n■ 게임 안에서 켜고 끄는 곳\r\n"+d[2]+"\r\n\r\n■ 같이 못 쓰는 것·주의\r\n"+d[3];
  var a=appliedInfo!=null?appliedInfo[id-1]:null;
  if(loaded==null){detailTitle.Text="게임 적용 확인";detail.Text="게임 폴더를 먼저 확인해 주세요.";return;}
  if(!loaded.On[id-1]){detailTitle.Text="게임 적용 확인";detail.Text="이 번호는 설치되어 있지 않습니다.";return;}
  detailTitle.Text="게임 적용 확인 (마지막 실행"+(a!=null&&a.Time!=""?": "+a.Time:"")+")";
  string diag=DiagSummary();
  detail.Text=a==null?"기록을 읽지 못했습니다.":a.Detail()+(diag!=""?"\r\n"+diag:"")+"\r\n기록 위치: 게임 폴더\\"+Engine.RecordsDir+"\\ (적용확인.log · runtime.log · 각 모드 기록)";
 }
 // R43: 게임 안 종합 진단(SAN14_Diag, 시작 30·90초)의 마지막 결과
 string DiagSummary(){
  try{string ap=Path.Combine(CleanRoot(),Engine.ApplyLogRel.Replace('/','\\'));if(!File.Exists(ap))return "";
   var d=Engine.LastDiag(File.ReadAllText(ap,Encoding.UTF8));if(d==null)return "";
   var b=new StringBuilder();b.AppendLine("■ 게임 안 종합 진단 ("+d[0]+", "+(d[1]=="check90"?"시작 90초":"시작 30초")+"): "+d[2]);
   for(int i=3;i<d.Length&&i<3+12;i++)b.AppendLine("  ✖ "+d[i]);
   return b.ToString().TrimEnd();}
  catch(Exception){return "";}
 }
 void OpenRecords(){try{string dir=Path.Combine(CleanRoot(),Engine.RecordsDir);if(!Directory.Exists(dir)&&loaded!=null)dir=Make().CollectRecords(log.Text);if(Directory.Exists(dir))System.Diagnostics.Process.Start("explorer.exe","\""+dir+"\"");else MessageBox.Show(this,"아직 기록 폴더가 없습니다. 게임 폴더를 확인한 뒤 다시 눌러 주세요.");}catch(Exception e){ErrorBox.Show(this,"기록 폴더",ErrorBox.Describe("기록 폴더를 여는 중",Path.Combine(CleanRoot(),Engine.RecordsDir),e,null));}}
 static string Detect(){
  var candidates=new List<string>();
  try{foreach(string key in new[]{@"HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Valve\Steam",@"HKEY_LOCAL_MACHINE\SOFTWARE\Valve\Steam",@"HKEY_CURRENT_USER\SOFTWARE\Valve\Steam"}){
   string steam=Microsoft.Win32.Registry.GetValue(key,"InstallPath",null) as string??Microsoft.Win32.Registry.GetValue(key,"SteamPath",null) as string;
   if(String.IsNullOrEmpty(steam))continue;candidates.Add(Path.Combine(steam,"steamapps","common","Romance_of_the_Three_Kingdoms_14"));
   string vdf=Path.Combine(steam,"steamapps","libraryfolders.vdf");
   if(File.Exists(vdf))foreach(var m in System.Text.RegularExpressions.Regex.Matches(File.ReadAllText(vdf),"\"path\"\\s+\"([^\"]+)\"").Cast<System.Text.RegularExpressions.Match>())candidates.Add(Path.Combine(m.Groups[1].Value.Replace("\\\\","\\"),"steamapps","common","Romance_of_the_Three_Kingdoms_14"));
  }}catch{}
  candidates.Add(@"C:\Program Files (x86)\Steam\steamapps\common\Romance_of_the_Three_Kingdoms_14");
  // R40 A22: 스팀이 실제로 깔아 둔 라이브러리(appmanifest_872410.acf 가 있는 곳)를 먼저. 옛 복사본 폴더에 깔리는 일 막기
  var found=new List<string>();foreach(string c in candidates){try{string full=Path.GetFullPath(c).TrimEnd('\\');if(File.Exists(Path.Combine(full,"SAN14CE_KO.exe"))&&!found.Any(x=>x.Equals(full,StringComparison.OrdinalIgnoreCase)))found.Add(full);}catch{}}
  string pick=found.FirstOrDefault(c=>{try{string sa=Path.GetDirectoryName(Path.GetDirectoryName(c));return File.Exists(Path.Combine(sa,"appmanifest_872410.acf"));}catch{return false;}})??found.FirstOrDefault()??"";
  otherCopies=found.Where(c=>!c.Equals(pick,StringComparison.OrdinalIgnoreCase)).ToList();
  return pick;
 }
 void LoadState(){
  if(busy)return;loaded=null;appliedInfo=null;
  if(String.IsNullOrWhiteSpace(CleanRoot())||!Directory.Exists(CleanRoot())){summary.Text="현재 상태: 게임 폴더를 선택해 주세요.";return;}
  try{
   var engine=Make();engine.Tx.Recover();var s=engine.Load();var st=engine.Status(s);loaded=s;loadedRoot=CleanRoot();
   Engine.AppliedInfo[] ap;try{ap=engine.AppliedDetail(s,Engine.RuntimeLogPath());}catch(Exception e){ap=null;WriteLog("게임 적용 기록을 읽지 못했습니다: "+e.Message);}
   appliedInfo=ap;int okN=0,partN=0,failN=0;
   for(int i=0;i<Spec.Count;i++){var row=grid.Rows[Spec.RowOf(i+1)];row.Cells[0].Value=false;row.Cells[3].Value=st[i];row.Cells[3].Style.ForeColor=st[i].StartsWith("설치됨")?Color.DarkGreen:st[i]=="미설치"?Color.DimGray:Color.DarkOrange;
    var a=ap!=null?ap[i]:null;string cell=a==null?"":a.Cell;row.Cells[4].Value=cell;row.Cells[4].ToolTipText=cell;
    Color col=Color.DimGray;if(a!=null){if(a.State=="OK"||a.State=="FILE"){col=Color.DarkGreen;okN++;}else if(a.State=="PART"){col=Color.FromArgb(196,127,0);partN++;}else if(a.State=="FAIL"){col=Color.Firebrick;failN++;}}
    row.Cells[4].Style.ForeColor=col;}
   int n=s.On.Count(x=>x);
   summary.Text="현재 상태: "+(n==0?"설치된 항목 없음":n+"개 항목 설치됨")+(n>0?" · 게임 적용: 확인 "+okN+" / 일부 "+partN+" / 실패 "+failN:"")+" · 새 항목 "+(Spec.Count-Spec.FirstNew+1)+"개(26~"+Spec.Count+")"+(s.Version!=0&&s.Version!=7?" (이전 설치기 기록 — [선택 설치]를 누르면 1.0.1용으로 갱신·정리합니다)":"");
   try{var miss=engine.MissingPayloads(Enumerable.Repeat(true,Spec.Count).ToArray());if(miss.Count>0&&!missNoted){missNoted=true;WriteLog("참고: 설치 자료 일부가 보이지 않습니다("+miss[0]+(miss.Count>1?" 외 "+(miss.Count-1)+"개":"")+"). 받은 ZIP 을 모두 같은 새 폴더에 풀어 주세요. 그 자료가 필요한 번호를 고르면 설치하지 않고 안내합니다.");}}catch(Exception){}
   try{var mm=engine.MissingModelPayloads();if(mm.Count>0&&!modelNoted){modelNoted=true;WriteLog("참고: 별도 ZIP 자료(10번 추가 3D 모델·31번 그래픽) "+mm.Count+"개가 보이지 않습니다. 이대로 설치하면 그 부분만 건너뜁니다(10번은 기본 모델 0~24만). 받은 ZIP 을 모두 같은 폴더에 풀어 주세요.");}}catch(Exception){}
   // R40 A22: 실행 파일·공통 파일 문제는 아래 기록줄만이 아니라 맨 위 상태줄에 빨갛게
   string exeKind=Engine.ExeKind(Path.Combine(CleanRoot(),"SAN14CE_KO.exe"));List<string> baseCh;try{baseCh=engine.BaseChanged(s);}catch(Exception){baseCh=new List<string>();}
   string warn=exeKind!=""?" · ⚠ "+exeKind:baseCh.Count>0?" · ⚠ 공통 파일 "+baseCh.Count+"개가 바뀜([선택 설치]로 복구)":"";
   if(s.RetiredOn){summary.Text+=" · 12번 안개는 이번 판에서 빠짐([선택 설치]를 누르면 지움)";WriteLog("참고: 12번(필드 안개)은 R41 부터 통합패치에서 빠졌습니다. 설치돼 있던 안개 파일은 [선택 설치]를 누르면 지웁니다. 미니맵은 27번(독립 미니맵)으로 쓰세요.");}
   summary.Text+=warn;summary.ForeColor=warn!=""?Color.Firebrick:SystemColors.ControlText;
   if(exeKind!="")WriteLog("주의: "+exeKind+". 통합패치는 스팀 원본 "+Spec.GameLabel+" 실행 파일(SAN14CE_KO.exe)에서만 켜집니다. 스팀 [게임 파일 무결성 확인]으로 원본을 되돌리세요.");
   if(baseCh.Count>0)WriteLog("주의: 통합패치 공통 파일이 설치 때와 다릅니다(다른 패치가 덮어썼을 수 있음): "+String.Join(", ",baseCh.Take(4).ToArray())+(baseCh.Count>4?" 외 "+(baseCh.Count-4)+"개":"")+" — [선택 설치]를 누르면 되돌립니다.");
   if(otherCopies.Count>0&&!copiesNoted){copiesNoted=true;WriteLog("참고: 게임 폴더가 여러 곳에 있습니다("+String.Join(" / ",otherCopies.ToArray())+"). 스팀이 실제로 실행하는 폴더에 설치해야 합니다.");}
   if(failN>0)WriteLog("게임 적용 실패 "+failN+"개: 목록에서 그 번호를 누르면 오른쪽에 이유가 나옵니다.");
   ShowDetail();
  }catch(Exception e){summary.Text="현재 상태: 확인할 수 없음";WriteLog(e.Message);}
 }
 void SetBusy(bool b){busy=b;foreach(Control c in new Control[]{grid,browse,refresh,tabAll,tabNone,tabInstall,tabRemove,allSel,allNone,allInstall,allRemove,records,target,tabs})c.Enabled=!b;Cursor=b?Cursors.WaitCursor:Cursors.Default;}
 // 선택 설치/제거 → 원하는 결과 집합(현재 설치 ∪ 선택 / 현재 설치 − 선택)으로 바꿔 기존 설치 엔진에 넘김
 void Start(bool install,bool tabOnly){
  if(busy)return;
  if(loaded==null){MessageBox.Show(this,"먼저 게임 폴더를 확인해 주세요.");return;}
  var sel=Selected(tabOnly);
  if(!sel.Any(x=>x)){MessageBox.Show(this,install?"설치할 항목을 체크해 주세요.":"제거할 항목을 체크해 주세요.");return;}
  var wanted=Engine.Compose(loaded.On,sel,install);
  var engine=Make();
  if(install){
   Spec.ForeignFont=delegate(string root){return engine.IsForeignFont();};
   if(!ResolveConflicts(wanted,engine))return;
  }else{
   var removing=sel;string note=Spec.RemovalNote(loaded.On,removing);
   string list=String.Join(", ",Spec.Order.Where(id=>removing[id-1]&&loaded.On[id-1]).Select(id=>Spec.Num(id)+"번").ToArray());
   if(list=="")list="(설치된 항목 없음)";
   bool all=!wanted.Any(x=>x);
   if(ErrorBox.Ask(this,"선택 제거",(all?"설치된 패치를 모두 제거하고 게임 데이터 파일을 "+Spec.GameLabel+" 원본으로 되돌립니다.\r\n":"다음 항목을 제거합니다: "+list+"\r\n")+(note!=""?"\r\n같이 바뀌는 것:\r\n"+note:"")+"\r\n사용자 음원·저장 데이터·다른 패치 파일은 건드리지 않습니다. 계속할까요?",new[]{"제거","취소"})!=0)return;
  }
  Run(wanted,engine,install);
 }
 bool ResolveConflicts(bool[] wanted,Engine engine){
  string root=CleanRoot();var notices=new List<string>();var resolved=new HashSet<string>();
  foreach(var c in Spec.Conflicts){
   if(!c.Relevant(loaded.On,wanted))continue; // 이번에 새로 까는 번호와 관계없는 충돌·알림은 안 띄움
   string msg=c.Check(wanted,root);if(msg==null)continue;
   if(c.Kind==Spec.ConflictKind.Notice){notices.Add("· "+c.Title+": "+c.Message);continue;}
   int pick=ErrorBox.Ask(this,c.Title,msg,c.Choices);
   WriteLog("충돌 "+c.Key+": "+(pick<0?"취소":c.Choices[pick]));
   if(!Spec.ApplyChoice(c.Key,pick,wanted,resolved))return false;
   if(c.Key=="20-font"&&resolved.Contains("20-font"))engine.ForceFont=true;
  }
  // 선택이 바뀌었으면 다시 한 번(빼기로 다른 충돌이 사라질 수 있음) — 차단 규칙만 재검사, "둘 다 설치"로 해결한 규칙은 제외
  var left=Spec.RemainingBlock(wanted,root,resolved,loaded.On);
  if(left!=null){MessageBox.Show(this,"아직 같이 못 쓰는 조합이 남아 있습니다: "+left.Title);return false;}
  if(notices.Count>0&&ErrorBox.Ask(this,"참고",String.Join("\r\n\r\n",notices.ToArray())+"\r\n\r\n이대로 설치할까요?",new[]{"설치","취소"})!=0)return false;
  return true;
 }
 void Run(bool[] on,Engine engine,bool install){
  SetBusy(true);
  var ids=Spec.Order.Where(id=>on[id-1]).Select(id=>Spec.Num(id)).ToArray();
  WriteLog((install?"선택 설치 시작 → 적용 후 설치돼 있을 항목: ":"선택 제거 시작 → 남는 항목: ")+(ids.Length==0?"없음":String.Join(", ",ids)+"번"));
  var worker=new BackgroundWorker();Exception error=null;
  worker.DoWork+=delegate{try{engine.Install(on,delegate(int i,int total){if(i%20==0||i==total)WriteLog("파일 처리 "+i+"/"+total);});}catch(Exception e){error=e;}};
  worker.RunWorkerCompleted+=delegate{
   SetBusy(false);
   try{engine.CollectRecords(log.Text);}catch(Exception){}
   if(error!=null){
    WriteLog(error.Message);
    var ie=error as InstallException;
    ErrorBox.Show(this,install?"설치하지 않음":"제거하지 않음",ErrorBox.Describe(install?"선택한 항목을 설치하는 중":"선택한 항목을 제거하는 중",ie!=null?ie.Target:null,error,
     ie!=null?Fix(ie):"게임과 런처를 닫고, ZIP 둘을 같은 새 폴더에 풀었는지, 게임 폴더에 쓰기 권한이 있는지 확인한 뒤 다시 눌러 주세요."));
   }
   else{
    var b=new StringBuilder();b.AppendLine(install?"설치했습니다. 게임을 실행해 확인해 주세요.":(on.Any(x=>x)?"제거했습니다.":"모두 제거했습니다."));
    if(engine.ModelSkip!="")b.AppendLine("· 10번 추가 모델은 건너뜀: "+engine.ModelSkip);
    if(engine.ScreenSkip!="")b.AppendLine("· 31번 그래픽은 건너뜀: "+engine.ScreenSkip);
    if(install)b.AppendLine("게임 안 정보창 → 모드 버튼에서 세부 스위치를 바꿀 수 있습니다. 게임을 한 번 실행한 뒤 [상태 새로고침]을 누르면 번호별 적용 결과가 나옵니다.");
    MessageBox.Show(this,b.ToString(),"완료");
   }
   LoadState();worker.Dispose();
  };
  worker.RunWorkerAsync();
 }
 static string Fix(InstallException e){
  string m=e.Message;
  if(m.Contains("게임과 게임 런처"))return "게임과 런처를 닫은 뒤 다시 눌러 주세요.";
  if(m.Contains("같은 새 폴더"))return "ZIP 을 전부(1of n … n of n) 같은 새 폴더에 풀고 다시 실행해 주세요. 백신이 파일을 지웠으면 예외 처리 후 다시 풀어 주세요.";
  if(m.Contains("손상"))return "압축을 새 폴더에 다시 풀어 주세요.";
  if(m.Contains(" 전용입니다")||m.Contains("확인할 수 없습니다"))return "Steam 에서 게임을 최신("+Spec.GameLabel+")으로 업데이트한 뒤 다시 실행해 주세요.";
  if(m.Contains("다른 패치")||m.Contains("다른 프로그램"))return "그 파일을 쓰는 다른 패치를 먼저 지우거나, 해당 번호의 체크를 풀고 설치해 주세요.";
  if(m.Contains("무결성"))return "Steam 라이브러리 → 게임 속성 → 설치된 파일 → 무결성 확인을 한 뒤 다시 설치해 주세요.";
  return "오류 글자를 댓글로 알려 주세요.";
 }
}
}
