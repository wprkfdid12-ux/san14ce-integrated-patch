namespace San14Patch101 { public static class ManifestHash { public const string Value="691fe7de67bf997fce6ef38a1b0be208060a22a5594198d98732a71afb139e34"; } }
