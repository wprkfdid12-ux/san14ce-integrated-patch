﻿삼국지14 CE BGM 추가 기능 런타임

이 폴더는 설치기의 9번 항목이 관리합니다.
- Python 런타임: Python Software Foundation License
- FFmpeg: 동봉 licenses 폴더 참조
- 사용자 음원은 설치 파일에 포함되지 않습니다.