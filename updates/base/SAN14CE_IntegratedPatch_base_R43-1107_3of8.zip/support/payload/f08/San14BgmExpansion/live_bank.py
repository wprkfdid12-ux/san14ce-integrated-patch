"""Small native KTSR banks with a separate memory-backed KTAC stream.

These files are not installed into RRPreview.rdb. The game's KTSL engine loads
them via its own bank and external-stream interfaces on the game thread.
"""
import struct
import zlib
import bank

FIRST_ID = 117
LAST_ID = 254  # v3 native getter preserves 0xFF as the default sentinel.
MAX_TRACKS = LAST_ID - FIRST_ID + 1


def make(config, audio, logical):
    if not FIRST_ID <= logical <= LAST_ID:
        raise ValueError('추가곡 ID 범위 오류')
    info = bank.validate_ktac(audio)
    if len(audio) > 200*1024*1024:
        raise ValueError('실시간 등록 음원은 곡당 200MB까지 지원합니다.')
    if config[:4] != b'ASRS' or config[16:24] != b'KTSRw{H\x1a':
        raise ValueError('원본 설정 스냅샷 오류')
    cue = bytearray(next(config[a:a+n] for a,k,n,_ in bank.chunks(config,80) if k==0x368C88BD))
    sound = bytearray(next(config[a:a+n] for a,k,n,_ in bank.chunks(config,80) if k==0x70CBCCC5))
    if len(cue)!=224 or len(sound)!=112 or bank.u32(cue,8)!=bank.u32(cue,180):
        raise ValueError('알려진 CE 설정과 다릅니다.')
    # Revision-specific IDs allow an already-playing previous version to finish.
    sid = zlib.crc32(('SAN14_LIVE_V2_%d_'%logical+bank.digest(audio)).encode('ascii'))
    if not sid:
        raise ValueError('오디오 해시 오류')
    for b in (cue,sound): bank.put(b,8,sid)
    bank.put(cue,180,sid)
    name = ('LIVE%03d'%logical).encode()+b'\0'
    for b,off,mask in ((cue,40,0x200),(sound,24,8)):
        bank.put(b,12,bank.u32(b,12)&~mask)
        p=bank.u32(b,off)
        # Original name allocation is eight bytes, including the terminator.
        if p+len(name)>len(b): raise ValueError('진단용 이름 범위 오류')
        b[p:p+len(name)]=name
    h=bank.u32(sound,bank.u32(sound,20))
    if bank.u32(sound,h)!=0x7D43D038: raise ValueError('외부 스트림 헤더 오류')
    bank.put(sound,h+24,48000)
    bank.put(sound,h+28,info['samples'])
    bank.put(sound,h+32,0x840)  # PC KTAC codec discriminator, not a loop offset.
    bank.put(sound,h+36,0)     # Loop from the beginning (cue retains native BGM routing).
    bank.put(sound,h+52,96)    # KTSR header + native external-stream chunk header.
    bank.put(sound,h+56,len(audio))
    result=bytearray(config[16:80])+cue+sound
    bank.put(result,24,len(result));bank.put(result,28,len(result))
    validate(result,audio,sid)
    return bytes(result),sid


def validate(config,audio,sid):
    bank.validate_ktac(audio)
    if len(config)!=400 or config[:8]!=b'KTSRw{H\x1a' or bank.u32(config,24)!=400 or bank.u32(config,28)!=400:
        raise ValueError('실시간 뱅크 헤더 오류')
    rows=list(bank.chunks(config,64))
    if [(k,n,s) for _,k,n,s in rows]!=[(0x368C88BD,224,sid),(0x70CBCCC5,112,sid)]:
        raise ValueError('실시간 뱅크 청크 오류')
    sound=config[288:];h=bank.u32(sound,bank.u32(sound,20))
    if bank.u32(config,64+180)!=sid or bank.u32(sound,h+52)!=96 or bank.u32(sound,h+56)!=len(audio):
        raise ValueError('실시간 뱅크 참조 오류')
    if struct.unpack_from('<4I',sound,h+24)!=(48000,bank.validate_ktac(audio)['samples'],0x840,0):
        raise ValueError('실시간 뱅크 음원 설정 오류')


def stream(config,audio,sid):
    validate(config,audio,sid)
    header=bytearray(config[:64])
    bank.put(header,4,0xFCDD9402)
    chunk=bytearray((32+len(audio)+15)&~15)
    struct.pack_into('<5I',chunk,0,0x15F4D409,len(chunk),sid,32,len(audio))
    chunk[32:32+len(audio)]=audio
    result=header+chunk
    bank.put(result,24,len(result));bank.put(result,28,len(result))
    return bytes(result)
