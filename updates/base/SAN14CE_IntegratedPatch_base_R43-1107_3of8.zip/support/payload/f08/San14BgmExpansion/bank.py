"""CE BGM extension builder. Existing streams/chunks remain byte-for-byte intact.

No game writes occur here. The installer consumes the staged result separately.
"""
from pathlib import Path
import hashlib
import json
import math
import re
import struct
import subprocess
import zlib

FIRST_ID = 117
LAST_ID = 127  # CEditBgmData reads a SIGNED byte; 128 would become negative.
BANK_ID = 0xB090FFEC
STREAM_ID = 0x9DA765BF


def u32(b, o):
    return struct.unpack_from('<I', b, o)[0]


def put(b, o, n, fmt='I'):
    struct.pack_into('<' + fmt, b, o, n)


def digest(b):
    return hashlib.sha256(b).hexdigest()


def records(b):
    if b[:8] != b'_DRK0000':
        raise ValueError('지원하지 않는 RDB입니다.')
    o = u32(b, 8)
    count = 0
    while o < len(b):
        if b[o:o+8] != b'IDRK0000':
            raise ValueError('RDB 레코드 헤더 오류')
        size, packed, plain = struct.unpack_from('<QQQ', b, o+8)
        if size < 48 or packed > size-48 or o+size > len(b):
            raise ValueError('RDB 레코드 범위 오류')
        yield o, size, packed, plain, u32(b, o+36)
        o = (o+size+3) & ~3
        count += 1
    if o != len(b) or count != u32(b, 16):
        raise ValueError('RDB 개수 오류')


def unpack_bank(rdb_path):
    index = Path(rdb_path).read_bytes()
    matches = [r for r in records(index) if r[4] == BANK_ID]
    if len(matches) != 1:
        raise ValueError('BGM 설정 뱅크가 유일하지 않습니다.')
    o, size, packed, plain, _ = matches[0]
    location = index[o+size-packed:o+size].rstrip(b'\0').decode('ascii')
    m = re.fullmatch(r'([0-9a-f]+)@([0-9a-f]+)(?:#([0-9a-f]+))?(?:&([0-9a-f]+))?', location)
    if not m:
        raise ValueError('지원하지 않는 설정 뱅크 위치')
    offset, length, part, sub = (int(x, 16) if x is not None else None for x in m.groups())
    container = Path(str(rdb_path) + '.bin' + (str(part) if part is not None else '') + ('_'+str(sub) if sub is not None else ''))
    with container.open('rb') as f:
        f.seek(offset)
        block = f.read(length)
    if len(block) != length or block[:8] != b'IDRK0000' or u32(block, 36) != BANK_ID:
        raise ValueError('설정 뱅크 파일 헤더 오류')
    total, compressed, original = struct.unpack_from('<QQQ', block, 8)
    if total != length or total-compressed != 56 or original != plain:
        raise ValueError('설정 뱅크 크기 오류')
    raw = block[56:]
    if u32(block, 44) & 0x100000:
        out = bytearray()
        at = 0
        while at < len(raw):
            n = u32(raw, at)
            at += 4
            if not n:
                break
            if n > len(raw)-at:
                raise ValueError('압축 청크 범위 오류')
            dec = zlib.decompressobj()
            out.extend(dec.decompress(raw[at:at+n]))
            if not dec.eof:
                raise ValueError('불완전한 압축 청크')
            at += n
        if at != len(raw):
            raise ValueError('압축 뱅크 끝 오류')
        raw = bytes(out)
    if len(raw) != plain:
        raise ValueError('설정 뱅크 해제 크기 오류')
    return index, raw, block[:56]


def chunks(b, start):
    at = start
    while at < len(b):
        kind, size, sid = struct.unpack_from('<III', b, at)
        if size < 12 or at+size > len(b):
            raise ValueError('오디오 청크 범위 오류')
        yield at, kind, size, sid
        at += size
    if at != len(b):
        raise ValueError('오디오 끝 오류')


def validate_ktac(b):
    if len(b) < 64 or b[:8] != b'KTAC\0\0\0\1' or u32(b, 8) != len(b):
        raise ValueError('KTAC 헤더 오류')
    payload, length = u32(b, 12), u32(b, 16)
    rate, samples = u32(b, 24), u32(b, 28)
    channels, frame_samples, delay, padding = struct.unpack_from('<4H', b, 32)
    table, count = u32(b, 56), u32(b, 60)
    if not count or frame_samples != 1024 or channels != 2 or rate != 48000:
        raise ValueError('48kHz 스테레오 AAC-LC만 지원합니다.')
    if table < 64 or table+4*count > payload or payload+length > len(b):
        raise ValueError('KTAC 프레임 표 범위 오류')
    sizes = struct.unpack_from('<%dI' % count, b, table)
    if min(sizes) == 0 or sum(sizes) != length or samples != count*1024 or samples <= delay+padding:
        raise ValueError('KTAC 프레임 수/길이 오류')
    return dict(rate=rate, samples=samples-delay-padding, delay=delay, padding=padding,
                frames=count, payload_bytes=length, seconds=(samples-delay-padding)/rate)


def from_adts(data, source_samples):
    at = 0
    frames = []
    while at < len(data):
        h = data[at:at+7]
        if len(h) != 7 or h[0] != 255 or h[1] & 0xF6 != 0xF0:
            raise ValueError('ADTS 동기 오류')
        channels = ((h[2] & 1) << 2) | (h[3] >> 6)
        if h[2] >> 6 != 1 or (h[2] >> 2) & 15 != 3 or channels != 2 or h[6] & 3:
            raise ValueError('48kHz 스테레오 AAC-LC 필요')
        length = ((h[3] & 3) << 11) | (h[4] << 3) | (h[5] >> 5)
        header = 7 if h[1] & 1 else 9
        if length <= header or at+length > len(data):
            raise ValueError('ADTS 프레임 범위 오류')
        frames.append(data[at+header:at+length])
        at += length
    if not frames:
        raise ValueError('빈 AAC')
    padding = len(frames)*1024-1024-source_samples
    if not 0 <= padding <= 65535:
        raise ValueError('인코더 지연/패딩 불일치')
    head = bytearray(64)
    head[:8] = b'KTAC\0\0\0\1'
    payload = b''.join(frames)
    offset = 64+4*len(frames)
    for o, v in ((8, offset+len(payload)), (12, offset), (16, len(payload)), (20, 2),
                 (24, 48000), (28, len(frames)*1024), (40, 1), (44, len(frames)-1),
                 (56, 64), (60, len(frames))):
        put(head, o, v)
    struct.pack_into('<4H', head, 32, 2, 1024, 1024, padding)
    struct.pack_into('<2H', head, 48, 0, padding)
    result = bytes(head)+struct.pack('<%dI' % len(frames), *(len(f) for f in frames))+payload
    validate_ktac(result)
    return result


def convert(source, ffmpeg, folder, bitrate=256, start=0.0, end=None, fade=5.0):
    """Decode once to PCM to measure EXACT samples, then encode at chosen bitrate."""
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    if any(not math.isfinite(v) for v in (start,fade) + (() if end is None else (end,))) or bitrate not in (192, 256, 320) or start < 0 or fade < 0 or fade > 30 or (end is not None and end <= start):
        raise ValueError('구간/음질 설정 오류')
    pcm = folder/'audio.pcm'
    adts = folder/'audio.aac'
    flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    def run(args):
        r = subprocess.run([str(ffmpeg), '-hide_banner', '-nostdin', '-v', 'error', '-y']+args,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=flags, timeout=1800)
        if r.returncode:
            raise ValueError(r.stderr.decode('utf-8', errors='replace')[-3000:])
    # Avoid shell parsing of user-selected paths; input is always a separate argv.
    args = ['-i', str(Path(source).resolve()), '-map', '0:a:0', '-vn', '-ss', str(start)]
    if end is not None:
        args += ['-t', str(end-start)]
    run(args+['-ar', '48000', '-ac', '2', '-f', 's16le', str(pcm)])
    size = pcm.stat().st_size
    if size % 4 or not 1920 <= size <= 48000*4*3600:
        raise ValueError('음원은 0.01초~60분 범위여야 합니다.')
    samples = size//4
    duration = samples/48000
    if fade >= duration:
        raise ValueError('페이드 시간은 선택 구간보다 짧아야 합니다.')
    args = ['-f', 's16le', '-ar', '48000', '-ac', '2', '-i', str(pcm)]
    if fade:
        args += ['-af', 'afade=t=out:st=%.9f:d=%.9f' % (duration-fade, fade)]
    run(args+['-c:a', 'aac', '-b:a', str(bitrate)+'k', '-f', 'adts', str(adts)])
    result = from_adts(adts.read_bytes(), samples)
    return result


def validate_banks(config, stream):
    if config[:4] != b'ASRS' or config[16:24] != b'KTSRw{H\x1a':
        raise ValueError('ASRS 헤더 오류')
    if u32(config, 8) != len(config) or u32(config, 40) != len(config)-16 or u32(config, 44) != len(config)-16:
        raise ValueError('ASRS 크기 오류')
    if stream[:8] != b'IDRK0000' or stream[56:60] != b'TSRS' or stream[72:80] != b'KTSR\x02\x94\xdd\xfc':
        raise ValueError('TSRS 헤더 오류')
    if struct.unpack_from('<3Q', stream, 8) != (len(stream), len(stream)-56, len(stream)-56):
        raise ValueError('TSRS 외부 크기 오류')
    if u32(stream, 64) != len(stream)-56 or u32(stream, 96) != len(stream)-72 or u32(stream, 100) != len(stream)-72:
        raise ValueError('TSRS 내부 크기 오류')
    streams = {}
    for at, kind, size, sid in chunks(stream, 136):
        if kind != 0x15F4D409 or u32(stream, at+12) != 32 or sid in streams:
            raise ValueError('스트림 청크 오류/중복')
        n = u32(stream, at+16)
        if n > size-32 or n < 64 or stream[at+32:at+36] != b'KTAC':
            raise ValueError('스트림 KTAC 범위 오류')
        if u32(stream, at+40) != n:
            raise ValueError('스트림 KTAC 크기 불일치')
        streams[sid] = (at+32-72, n)
    configs, sounds = set(), set()
    for at, kind, size, sid in chunks(config, 80):
        if kind == 0x368C88BD:
            if sid in configs:
                raise ValueError('중복 설정 ID')
            configs.add(sid)
        elif kind == 0x70CBCCC5:
            if sid in sounds or u32(config, at+16) != 1:
                raise ValueError('중복/지원하지 않는 사운드')
            h = at+u32(config, at+u32(config, at+20))
            if h+64 > at+size or u32(config, h) != 0x7D43D038:
                raise ValueError('사운드 헤더 범위 오류')
            if streams.get(sid) != (u32(config, h+52), u32(config, h+56)):
                raise ValueError('사운드 외부 스트림 참조 오류')
            sounds.add(sid)
    if configs != sounds or sounds != set(streams):
        raise ValueError('설정/사운드/스트림 ID 집합 불일치')
    return configs


def extend(config, stream, tracks):
    original_ids = validate_banks(config, stream)
    if len(original_ids) != 88:
        raise ValueError('확장 전 88곡 원본 스냅샷이 필요합니다.')
    if len(tracks) > LAST_ID-FIRST_ID+1:
        raise ValueError('이번 버전은 추가 11곡(ID 117~127)까지 지원합니다.')
    ctemplate = next(config[a:a+n] for a,k,n,s in chunks(config,80) if k == 0x368C88BD)
    stemplate = next(config[a:a+n] for a,k,n,s in chunks(config,80) if k == 0x70CBCCC5)
    template_id = u32(ctemplate,8)
    if template_id != u32(stemplate,8) or len(ctemplate) != 224 or u32(ctemplate,180) != template_id:
        raise ValueError('알려진 CE BGM 설정 구조와 다릅니다.')
    out_c, out_s = bytearray(config), bytearray(stream)
    used = set(original_ids)
    for i, track in enumerate(tracks):
        logical = FIRST_ID+i
        if track['id'] != logical:
            raise ValueError('추가 ID는 117부터 연속되어야 합니다.')
        sid = zlib.crc32(('SAN14_CUSTOM_BGM_%d' % logical).encode('ascii'))
        if sid in used:
            raise ValueError('오디오 해시 충돌')
        used.add(sid)
        audio = track['audio']
        info = validate_ktac(audio)
        # Independent, variable-sized chunk: NO old slot capacity/bitrate fallback.
        chunk_size = (32+len(audio)+15) & ~15
        chunk = bytearray(chunk_size)
        struct.pack_into('<5I',chunk,0,0x15F4D409,chunk_size,sid,32,len(audio))
        chunk[32:32+len(audio)] = audio
        stream_offset = len(out_s)+32-72
        out_s.extend(chunk)
        cue, sound = bytearray(ctemplate), bytearray(stemplate)
        put(cue,8,sid); put(cue,180,sid); put(sound,8,sid)
        # Keep original cue envelope/bus/loop routing, replace only its wave ID.
        # Names are diagnostic; native menu names live in the UTF-16 manifest.
        name = ('BGM%03d' % logical).encode('ascii')+b'\0'
        for b, flags_offset, name_offset, mask in ((cue,12,40,0x200),(sound,12,24,8)):
            put(b,flags_offset,u32(b,flags_offset)&~mask)
            at = u32(b,name_offset)
            b[at:at+7] = name
        h = u32(sound,u32(sound,20))
        put(sound,h+24,48000); put(sound,h+28,info['samples'])
        put(sound,h+32,0); put(sound,h+36,info['samples'])
        put(sound,h+52,stream_offset); put(sound,h+56,len(audio))
        out_c.extend(cue); out_c.extend(sound)
        track['hash'] = sid
    put(out_c,8,len(out_c)); put(out_c,40,len(out_c)-16); put(out_c,44,len(out_c)-16)
    for at,val,fmt in ((8,len(out_s),'Q'),(16,len(out_s)-56,'Q'),(24,len(out_s)-56,'Q'),
                       (64,len(out_s)-56,'Q'),(96,len(out_s)-72,'I'),(100,len(out_s)-72,'I')):
        put(out_s,at,val,fmt)
    validate_banks(out_c,out_s)
    assert out_c[80:len(config)] == config[80:]
    assert out_s[136:len(stream)] == stream[136:]
    return bytes(out_c), bytes(out_s)


def build_index(index, wrapper, config, stream, part):
    """Use a NEW container file. Never append to existing/hardlinked containers."""
    block = bytearray(wrapper)
    put(block,8,56+len(config),'Q'); put(block,16,len(config),'Q'); put(block,24,len(config),'Q')
    put(block,44,u32(block,44)&~0x100000)
    block.extend(config)
    out = bytearray(index[:u32(index,8)])
    changed = []
    for o,size,packed,plain,kid in records(index):
        record = bytearray(index[o:o+size])
        if kid == BANK_ID:
            location = ('0@%x#%x' % (len(block),part)).encode('ascii')+b'\0'
            record = record[:size-packed]+location
            put(record,8,len(record),'Q'); put(record,16,len(location),'Q'); put(record,24,len(config),'Q')
            put(record,44,u32(record,44)&~0x100000)
            changed.append(kid)
        elif kid == STREAM_ID:
            put(record,24,len(stream)-56,'Q')
            changed.append(kid)
        out.extend(record)
        out.extend(bytes((-len(out))%4))
    if sorted(changed) != sorted((BANK_ID,STREAM_ID)):
        raise ValueError('RDB 대상 항목 누락/중복')
    list(records(out))
    return bytes(out), bytes(block)
