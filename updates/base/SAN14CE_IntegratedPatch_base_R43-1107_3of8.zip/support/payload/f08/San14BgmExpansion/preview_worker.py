"""Bounded, headless source preview. Decodes to PCM, never registers a BGM ID.

The game UI owns the request and stop marker. Closing the game stops playback.
No shell, Windows player window, catalog edits, or system volume changes.
"""
from pathlib import Path
import argparse
import ctypes as c
import queue
import subprocess
import tempfile
import threading
import time
import live_worker as w
import manager as m

BLOCK = 38400  # 0.2 seconds, 48 kHz stereo s16le


class WaveFormat(c.Structure):
    _pack_ = 1
    _fields_ = [('tag', c.c_ushort), ('channels', c.c_ushort), ('rate', c.c_uint),
                ('bytes_per_second', c.c_uint), ('align', c.c_ushort),
                ('bits', c.c_ushort), ('extra', c.c_ushort)]


class WaveHeader(c.Structure):
    _fields_ = [('data', c.c_void_p), ('length', c.c_uint), ('recorded', c.c_uint),
                ('user', c.c_size_t), ('flags', c.c_uint), ('loops', c.c_uint),
                ('next', c.c_void_p), ('reserved', c.c_size_t)]


class WaveOutput:
    def __init__(self):
        self.api = c.WinDLL('winmm')
        self.handle = c.c_void_p()
        self.slots = []
        self.api.waveOutOpen.argtypes = [c.POINTER(c.c_void_p), c.c_uint, c.POINTER(WaveFormat), c.c_size_t, c.c_size_t, c.c_uint]
        for name in ('waveOutPrepareHeader', 'waveOutWrite', 'waveOutUnprepareHeader'):
            getattr(self.api, name).argtypes = [c.c_void_p, c.POINTER(WaveHeader), c.c_uint]
        for name in ('waveOutReset', 'waveOutClose'):
            getattr(self.api, name).argtypes = [c.c_void_p]
        fmt = WaveFormat(1, 2, 48000, 192000, 4, 16, 0)
        self.check(self.api.waveOutOpen(c.byref(self.handle), 0xffffffff, c.byref(fmt), 0, 0, 0))

    @staticmethod
    def check(error):
        if error: raise OSError('미리듣기 오디오 출력 오류: '+str(error))

    def reap(self):
        while self.slots and self.slots[0][0].flags & 1:  # WHDR_DONE
            header, data = self.slots[0]
            self.check(self.api.waveOutUnprepareHeader(self.handle, c.byref(header), c.sizeof(header)))
            self.slots.pop(0)  # Keep both objects alive until driver releases them.

    def write(self, pcm):
        if len(pcm) % 4: raise ValueError('PCM 블록 길이 오류')
        data = c.create_string_buffer(pcm)
        header = WaveHeader(c.cast(data, c.c_void_p), len(pcm), 0, 0, 0, 0, None, 0)
        self.check(self.api.waveOutPrepareHeader(self.handle, c.byref(header), c.sizeof(header)))
        self.slots.append((header, data))
        self.check(self.api.waveOutWrite(self.handle, c.byref(header), c.sizeof(header)))

    def close(self):
        if not self.handle: return
        self.api.waveOutReset(self.handle)  # Immediately stop, including queued PCM.
        for header, data in self.slots:
            for _ in range(100):
                if not self.api.waveOutUnprepareHeader(self.handle, c.byref(header), c.sizeof(header)): break
                time.sleep(.01)
        self.slots.clear()
        self.api.waveOutClose(self.handle)
        self.handle = c.c_void_p()


def stream_source(source, should_stop, status, output_factory=WaveOutput):
    """Decode with a bounded queue; cancellation terminates only our decoder."""
    source = Path(source).resolve()
    if not source.is_file() or source.suffix.lower() not in ('.mp3', '.wav', '.flac', '.m4a', '.ogg'):
        raise ValueError('미리들을 음원 파일을 선택하세요.')
    output = None
    cancel = threading.Event()
    chunks = queue.Queue(maxsize=4)
    with tempfile.TemporaryFile() as errors:
        decoder = subprocess.Popen([str(m.FFMPEG), '-hide_banner', '-nostdin', '-v', 'error', '-i', str(source),
                                    '-map', '0:a:0', '-vn', '-ar', '48000', '-ac', '2', '-f', 's16le', 'pipe:1'],
                                   stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=errors,
                                   creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        def produce():
            try:
                while not cancel.is_set():
                    pcm = decoder.stdout.read(BLOCK)
                    while not cancel.is_set():
                        try: chunks.put(pcm, timeout=.05); break
                        except queue.Full: pass
                    if not pcm: break
            finally:
                decoder.stdout.close()
        reader = threading.Thread(target=produce, daemon=True)
        reader.start()
        started = ended = False
        try:
            while not should_stop():
                if output:
                    output.reap()
                    if len(output.slots) >= 4:
                        time.sleep(.01); continue
                if ended:
                    if not output or not output.slots: break
                    time.sleep(.01); continue
                try: pcm = chunks.get(timeout=.05)
                except queue.Empty:
                    if not reader.is_alive() and decoder.poll() is not None:
                        errors.seek(0);raise ValueError(errors.read().decode('utf-8', errors='replace')[-1500:] or '오디오 디코더가 종료되었습니다.')
                    continue
                if not pcm:
                    ended = True; continue
                if output is None: output = output_factory()
                output.write(pcm)
                if not started:
                    status('playing', '선택 음원 미리듣기 중'); started = True
            stopped = should_stop()
            if not stopped:
                decoder.wait(timeout=5)
                if decoder.returncode or not started:
                    errors.seek(0);raise ValueError(errors.read().decode('utf-8', errors='replace')[-1500:] or '재생할 오디오가 없습니다.')
            return 'stopped' if stopped else 'done'
        finally:
            cancel.set()
            if output: output.close()
            if decoder.poll() is None: decoder.terminate()
            try: decoder.wait(timeout=3)
            except subprocess.TimeoutExpired: decoder.kill(); decoder.wait()
            reader.join(3)


def run(request):
    request = w.request_path(request)
    result = request.with_suffix('.result.ini')
    def status(state, message):
        m.atomic(result, w.ini_bytes({'Result': {'State': state, 'Message': ' '.join(str(message).split())[:500]}}))
    parent = None
    kernel = c.WinDLL('kernel32', use_last_error=True)
    kernel.OpenProcess.argtypes = [c.c_uint, c.c_int, c.c_uint];kernel.OpenProcess.restype = c.c_void_p
    kernel.WaitForSingleObject.argtypes = [c.c_void_p, c.c_uint]
    kernel.CloseHandle.argtypes = [c.c_void_p]
    try:
        req = w.ini_read(request)['Preview']
        parent = kernel.OpenProcess(0x00100000, False, int(req['ParentPID']))
        if not parent: raise ValueError('게임 실행 상태를 확인할 수 없습니다.')
        status('loading', '미리듣기 준비 중')
        stop = request.with_suffix('.stop')
        def cancelled(): return stop.exists() or kernel.WaitForSingleObject(parent, 0) != 258
        state = stream_source(req['Source'], cancelled, status)
        status(state, '미리듣기를 멈췄습니다.' if state=='stopped' else '미리듣기 완료')
    except Exception as error:
        status('error', error)
    finally:
        if parent: kernel.CloseHandle(parent)


if __name__ == '__main__':
    p=argparse.ArgumentParser();p.add_argument('--request',required=True)
    run(p.parse_args().request)
