"""Headless converter for the native game UI. Never opens a Windows dialog.

Two-phase publication: ready -> game registers bank -> ack -> active catalog.
No game process writes, no RDB writes, no network. All paths are separate argv.
"""
from pathlib import Path
import argparse
import configparser
import json
import os
import shutil
import tempfile
import time
import uuid
import bank
import live_bank
import manager

HERE=manager.HERE
LIVE=HERE/'live'
JOBS=HERE/'jobs'
ASSETS=LIVE/'assets'
ACTIVE=LIVE/'active.ini'


def ini_read(path):
    p=configparser.ConfigParser(interpolation=None)
    p.read(path,encoding='utf-16')
    return p


def ini_bytes(sections):
    p=configparser.ConfigParser(interpolation=None)
    p.optionxform=str
    for key,values in sections.items(): p[key]={k:str(v) for k,v in values.items()}
    import io
    output=io.StringIO();p.write(output)
    return output.getvalue().encode('utf-16')


def rows_current():
    if not ACTIVE.exists(): return manager.load_library()
    p=ini_read(ACTIVE)
    name=p['Live']['Snapshot']
    if Path(name).name!=name or not name.endswith('.json'): raise ValueError('목록 스냅샷 경로 오류')
    rows=json.loads((LIVE/name).read_text(encoding='utf-8'))
    if len(rows)>live_bank.MAX_TRACKS: raise ValueError('추가곡 수 오류')
    seen=set()
    for row in rows:
        if not isinstance(row.get('id'),int) or not 117<=row['id']<=live_bank.LAST_ID or row['id'] in seen:
            raise ValueError('추가곡 ID 범위/중복 오류')
        seen.add(row['id'])
        manager.validate_title(row['name'])
        if Path(row['file']).name!=row['file'] or manager.sha(manager.LIB/row['file'])!=row['sha256']:
            raise ValueError('음원 체크섬 오류')
    return sorted(rows,key=lambda r:r['id'])


def catalog(rows):
    ids=[r['id'] for r in rows]
    if len(ids)>live_bank.MAX_TRACKS or len(set(ids))!=len(ids) or any(not 117<=i<=live_bank.LAST_ID for i in ids):
        raise ValueError('추가곡 ID 범위/중복 오류')
    rows=sorted(rows,key=lambda r:r['id'])
    ASSETS.mkdir(parents=True,exist_ok=True)
    original=(manager.BASE/'config.asrs').read_bytes()
    snapshot='tracks-'+bank.digest(json.dumps(rows,sort_keys=True,ensure_ascii=False).encode())+'.json'
    manager.write_json(LIVE/snapshot,rows)
    # Count is the high-water mark, NOT the number of occupied slots.
    sections={'Live':{'Version':3,'Count':max(ids,default=116)+1,'Registered':len(rows),'Snapshot':snapshot}}
    seen=set()
    for r in rows:
        audio=(manager.LIB/r['file']).read_bytes()
        config,sid=live_bank.make(original,audio,r['id'])
        if sid in seen: raise ValueError('오디오 해시 충돌')
        seen.add(sid)
        stem=bank.digest(config)
        immutable_asset(ASSETS/(stem+'.ktsr'),config)
        stream=live_bank.stream(config,audio,sid)
        stream_name=bank.digest(stream)+'.srst'
        immutable_asset(ASSETS/stream_name,stream)
        # Fixed filenames only. No arbitrary native-side filesystem reads.
        sections[str(r['id'])]={'Hash':sid,'Name':r['name'],'Bank':stem+'.ktsr',
                                'Stream':stream_name,'Bytes':len(audio)}
    return ini_bytes(sections)


def immutable_asset(path,data):
    # A running game may hold a read-only file mapping. Never replace that file,
    # even with identical bytes; Windows correctly refuses such replacement.
    if path.exists():
        if manager.sha(path)!=bank.digest(data): raise ValueError('등록 음원 자산이 변경되었습니다: '+path.name)
    else: manager.atomic(path,data)


def bootstrap():
    with manager.lock():
        rows=rows_current()
        manager.atomic(ACTIVE,catalog(rows))
    return len(rows)


def request_path(value):
    p=Path(value).resolve()
    if p.parent!=JOBS.resolve() or p.suffix!='.ini' or not p.stem.isdigit():
        raise ValueError('작업 요청 경로 오류')
    return p


def prepare(request):
    req=ini_read(request)['Job']
    operation=req['Operation']
    if operation not in ('convert','rename'): raise ValueError('작업 종류 오류')
    name=req['Name'].strip();manager.validate_title(name)
    logical=int(req['Id'])
    rows=rows_current()
    if not 117<=logical<=live_bank.LAST_ID: raise ValueError('추가곡 ID 오류')
    index=next((i for i,r in enumerate(rows) if r['id']==logical),None)
    if operation=='rename':
        if index is None: raise ValueError('이름을 바꿀 곡이 없습니다.')
        rows[index]=dict(rows[index],name=name)
    else:
        source=Path(req['Source'])
        if not source.is_file(): raise ValueError('선택한 음원 파일을 찾을 수 없습니다.')
        # v4: whole track, no fades or trims, fixed high-quality AAC conversion.
        start,end,fade,rate=0,None,0,320
        JOBS.mkdir(parents=True,exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='live-encode-',dir=JOBS) as work:
            audio=bank.convert(source,manager.FFMPEG,work,rate,start,end,fade)
        info=bank.validate_ktac(audio)
        stem=bank.digest(audio)
        manager.atomic(manager.LIB/(stem+'.ktac'),audio)
        row=dict(id=logical,name=name,file=stem+'.ktac',sha256=stem,bitrate=rate,**info)
        if index is None: rows.append(row)
        else: rows[index]=row
    rows.sort(key=lambda r:r['id'])
    return rows,catalog(rows)


def run(request):
    request=request_path(request)
    result=request.with_suffix('.result.ini')
    pending=request.with_suffix('.catalog.ini')
    ack=request.with_suffix('.ack')
    def status(state,message):
        message=' '.join(str(message).split())[:500]
        manager.atomic(result,ini_bytes({'Result':{'State':state,'Message':message}}))
    try:
        with manager.lock():
            status('working','음원을 변환하고 있습니다. 잠시 기다려 주세요.')
            rows,data=prepare(request)
            manager.atomic(pending,data)
            status('ready','변환 완료. 게임 오디오에 등록 중입니다.')
            deadline=time.monotonic()+600
            while not ack.exists():
                if time.monotonic()>deadline: raise ValueError('게임 응답 시간이 지나 적용하지 않았습니다. 다시 시도하세요.')
                time.sleep(.1)
            if ack.read_bytes()!=b'APPLY': raise ValueError('게임 등록이 취소되었습니다. 기존 곡을 유지합니다.')
            # active.ini is the single commit point. Its immutable JSON snapshot
            # and audio/config assets were flushed before publication.
            if ACTIVE.exists(): shutil.copy2(ACTIVE,LIVE/('before-'+uuid.uuid4().hex+'.ini'))
            manager.atomic(ACTIVE,data)
            try:
                if manager.LIBRARY.exists(): shutil.copy2(manager.LIBRARY,manager.LIB/('tracks.before_'+uuid.uuid4().hex+'.json'))
                manager.write_json(manager.LIBRARY,rows)
            except OSError:
                pass  # v2 always reads the committed snapshot, not this legacy mirror.
            status('done','게임에 적용했습니다. 곡 목록을 갱신했습니다.')
    except Exception as error:
        status('error',error)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--request')
    parser.add_argument('--bootstrap',action='store_true')
    args=parser.parse_args()
    if args.bootstrap: print('기존 추가곡 보존:',bootstrap())
    elif args.request: run(args.request)
    else: parser.error('--request 또는 --bootstrap 필요')
