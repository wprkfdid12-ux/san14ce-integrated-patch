"""Local MP3 manager + guarded offline installer. No network or cloud API."""
from pathlib import Path
import argparse
import configparser
import contextlib
import ctypes
from ctypes import wintypes
import datetime
import hashlib
import json
import math
import os
import queue
import shutil
import subprocess
import sys
import tempfile
import threading
import uuid
import zlib
import bank

HERE=Path(__file__).resolve().parent
GAME=Path(os.environ.get('SAN14_GAME_ROOT', str(HERE.parent))).resolve()
LIB=HERE/'library'
LIBRARY=LIB/'tracks.json'
BASE=HERE/'baseline'
RECEIPT=HERE/'installed.json'
PYTHON=Path(sys.executable).with_name('pythonw.exe')
FFMPEG=HERE/'tools'/'ffmpeg.exe'
if not FFMPEG.is_file():
    # Development-tree fallback. The distributable always uses HERE/tools.
    FFMPEG=next((HERE.parent/'San14BgmTool/tools').rglob('ffmpeg.exe'))
EXE_HASH='07a047826cfc316dc9e3db6bfddc72b85e8d7de99743cc73a2d7199a1ad3aa40'
BASE_DLL_HASH='93ce85e4bb6a179b99d5a20fe6efabc5b067c3ea377d9c4baf34b6d69e4fd133'


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()


def atomic(path,data):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
    try:
        with temp.open('xb') as f:
            f.write(data);f.flush();os.fsync(f.fileno())
        os.replace(temp,path)
    finally:
        if temp.exists():temp.unlink()  # Only our uniquely named temporary file.


def write_json(path,value):
    atomic(path,json.dumps(value,ensure_ascii=False,indent=2).encode('utf-8'))


@contextlib.contextmanager
def lock():
    # Exclusive lifetime lock; Windows releases it if this process crashes.
    LIB.mkdir(exist_ok=True)
    import msvcrt
    with (LIB/'manager.lock').open('a+b') as f:
        f.seek(0)
        try:msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
        except OSError:raise ValueError('다른 음악 관리 창에서 작업 중입니다.')
        try:yield
        finally:f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)


def game_running():
    k=ctypes.WinDLL('kernel32',use_last_error=True)
    class Entry(ctypes.Structure):
        _fields_=[('size',wintypes.DWORD),('cnt',wintypes.DWORD),('pid',wintypes.DWORD),
                  ('heap',ctypes.c_size_t),('module',wintypes.DWORD),('threads',wintypes.DWORD),
                  ('parent',wintypes.DWORD),('priority',wintypes.LONG),('flags',wintypes.DWORD),('exe',wintypes.WCHAR*260)]
    k.CreateToolhelp32Snapshot.restype=wintypes.HANDLE
    k.Process32FirstW.argtypes=[wintypes.HANDLE,ctypes.POINTER(Entry)]
    k.Process32NextW.argtypes=k.Process32FirstW.argtypes
    k.CloseHandle.argtypes=[wintypes.HANDLE]
    h=k.CreateToolhelp32Snapshot(2,0)
    if h==ctypes.c_void_p(-1).value:raise OSError('프로세스 확인 실패')
    try:
        e=Entry();e.size=ctypes.sizeof(e);ok=k.Process32FirstW(h,ctypes.byref(e))
        while ok:
            if e.exe.upper().startswith('SAN14') and e.exe.lower().endswith('.exe'):return True
            ok=k.Process32NextW(h,ctypes.byref(e))
        return False
    finally:k.CloseHandle(h)


def load_library():
    rows=json.loads(LIBRARY.read_text(encoding='utf-8')) if LIBRARY.exists() else []
    if not isinstance(rows,list) or len(rows)>138:raise ValueError('음악 목록 오류')
    for i,r in enumerate(rows):
        if r['id']!=117+i:raise ValueError('추가곡 ID 순서 오류')
        validate_title(r['name'])
        p=(LIB/r['file']).resolve()
        if p.parent!=LIB.resolve() or not p.is_file():raise ValueError('음악 파일 경로 오류')
        if sha(p)!=r['sha256']:raise ValueError('등록 음원 체크섬 오류: '+r['name'])
    return rows


def validate_title(name):
    if not isinstance(name,str) or not name.strip() or len(name)>60 or len(name.encode('utf-16-le'))>120:
        raise ValueError('곡명은 1~60자(UTF-16 기준)로 입력하세요.')
    if any(ord(c)<32 for c in name) or any(c in name for c in '[]=\"'):
        raise ValueError('곡명에 제어 문자나 [ ] = " 문자를 사용할 수 없습니다.')


def snapshot():
    if BASE.exists():
        m=json.loads((BASE/'manifest.json').read_text(encoding='utf-8'))
        for name,value in m.items():
            if sha(BASE/name)!=value:raise ValueError('원본 스냅샷 손상: '+name)
        return
    _,c,w=bank.unpack_bank(GAME/'0002/RRPreview.rdb')
    s=(GAME/'0002/data/0x9da765bf.file').read_bytes()
    if len(bank.validate_banks(c,s))!=88:raise ValueError('최초 백업에는 확장 전 88곡 뱅크가 필요합니다.')
    # Persistent artifacts must inherit the project ACL. Python's secure
    # mkdtemp DACL is private to the sandbox account and unsuitable here.
    stage=HERE/('baseline-'+uuid.uuid4().hex);stage.mkdir()
    for name,data in (('config.asrs',c),('stream.file',s),('wrapper.bin',w)):(stage/name).write_bytes(data)
    write_json(stage/'manifest.json',{name:sha(stage/name) for name in ('config.asrs','stream.file','wrapper.bin')})
    os.replace(stage,BASE)


def active_ini(rows):
    lines=['[BGM]','Count='+str(117+len(rows)),'[Manager]','Python='+str(PYTHON),'Script='+str(HERE/'manager.py')]
    for r in rows:
        lines+=['['+str(r['id'])+']','Hash='+str(zlib.crc32(('SAN14_CUSTOM_BGM_%d'%r['id']).encode())), 'Name='+r['name']]
    return ('\r\n'.join(lines)+'\r\n').encode('utf-16')


def target_records(index):
    return {str(kid):bank.digest(index[o:o+n]) for o,n,_,_,kid in bank.records(index) if kid in (bank.BANK_ID,bank.STREAM_ID)}


def stage_build(status=print):
    if RECEIPT.exists() and json.loads(RECEIPT.read_text(encoding='utf-8')).get('native_version',0)>=2:
        raise ValueError('게임 내 음악 관리 버전이 설치되어 있습니다. 게임의 [음악 추가 / 관리]에서 적용하세요.')
    if sha(GAME/'SAN14CE_KO.exe')!=EXE_HASH:raise ValueError('지원하지 않는 CE 한국어 실행 파일입니다.')
    snapshot();rows=load_library()
    tracks=[dict(r,audio=(LIB/r['file']).read_bytes()) for r in rows]
    status('원곡 보존·새 음원 뱅크 구성 중…')
    c,s=bank.extend((BASE/'config.asrs').read_bytes(),(BASE/'stream.file').read_bytes(),tracks)
    index=(GAME/'0002/RRPreview.rdb').read_bytes()
    before={str(p):sha(GAME/p) for p in ('DINPUT8.dll','0002/RRPreview.rdb','0002/data/0x9da765bf.file')}
    receipt=json.loads(RECEIPT.read_text(encoding='utf-8')) if RECEIPT.exists() else None
    expected=receipt['dll_hash'] if receipt else BASE_DLL_HASH
    if before['DINPUT8.dll']!=expected:raise ValueError('기존 로더가 변경되었습니다. 모드 통합을 다시 확인해야 합니다.')
    if receipt:
        if before['0002/data/0x9da765bf.file']!=receipt['stream_hash'] or target_records(index)!=receipt['records']:
            raise ValueError('BGM 파일이 다른 도구로 바뀌었습니다. 덮어쓰지 않고 중단합니다.')
    else:
        _,actual,_=bank.unpack_bank(GAME/'0002/RRPreview.rdb')
        if actual!=(BASE/'config.asrs').read_bytes() or before['0002/data/0x9da765bf.file']!=sha(BASE/'stream.file'):
            raise ValueError('백업 후 원본 BGM이 변경되었습니다.')
    # Every generation uses its own file. Existing containers are never altered.
    part=next((p for p in range(99,10000) if not (GAME/('0002/RRPreview.rdb.bin%d'%p)).exists()),None)
    if part is None:raise ValueError('새 뱅크 컨테이너 번호 부족')
    idx,block=bank.build_index(index,(BASE/'wrapper.bin').read_bytes(),c,s,part)
    folder=HERE/('stage-'+uuid.uuid4().hex);folder.mkdir()
    payload={'DINPUT8.dll':(HERE/'build/DINPUT8.dll').read_bytes(),'0002/RRPreview.rdb':idx,
             '0002/data/0x9da765bf.file':s,'San14BgmExpansion.ini':active_ini(rows),
             '0002/RRPreview.rdb.bin%d'%part:block}
    for rel,data in payload.items():
        p=folder/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    write_json(folder/'plan.json',dict(before=before,files={k:bank.digest(v) for k,v in payload.items()},rows=rows))
    status('검증 완료: 원곡 88개 보존, 추가 %d곡. 아직 게임에 적용하지 않았습니다.'%len(rows))
    return folder


def apply(status=print):
    with lock():
        if game_running():raise ValueError('게임을 완전히 종료한 뒤 적용하세요. 등록/변환은 실행 중에도 가능합니다.')
        folder=stage_build(status)
        plan=json.loads((folder/'plan.json').read_text(encoding='utf-8'))
        if game_running():raise ValueError('준비 중 게임이 실행되었습니다. 적용 중단.')
        for rel,value in plan['before'].items():
            if sha(GAME/rel)!=value:raise ValueError('준비 중 게임 파일이 바뀌었습니다: '+rel)
        backup=HERE/'backups'/(datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:6])
        backup.mkdir(parents=True)
        existed={}
        for rel in plan['files']:
            p=GAME/rel;existed[rel]=p.exists()
            if p.exists():
                q=backup/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
                if sha(p)!=sha(q):raise ValueError('백업 검증 실패')
        journal=dict(game=str(GAME),existed=existed,stage=str(folder),state='prepared')
        write_json(backup/'transaction.json',journal)
        done=[]
        try:
            # Container and stream first, index next, manifest then loader last.
            order=sorted(plan['files'],key=lambda r: 4 if r=='DINPUT8.dll' else 3 if r.endswith('.ini') else 2 if r.endswith('.rdb') else 0)
            for rel in order:
                if game_running():raise ValueError('설치 도중 게임이 실행되어 되돌립니다.')
                if sha(folder/rel)!=plan['files'][rel]:raise ValueError('설치 후보 체크섬 오류')
                atomic(GAME/rel,(folder/rel).read_bytes());done.append(rel)
                if sha(GAME/rel)!=plan['files'][rel]:raise ValueError('적용 후 체크섬 오류')
            write_json(RECEIPT,dict(dll_hash=sha(GAME/'DINPUT8.dll'),stream_hash=sha(GAME/'0002/data/0x9da765bf.file'),
                                   records=target_records((GAME/'0002/RRPreview.rdb').read_bytes()),backup=str(backup),rows=plan['rows']))
            journal['state']='complete';write_json(backup/'transaction.json',journal)
        except Exception:
            for rel in reversed(done):
                if existed[rel]:atomic(GAME/rel,(backup/rel).read_bytes())
                # New unreferenced container is deliberately retained, not deleted.
                elif rel.endswith('.ini'):atomic(GAME/rel,active_ini([]))
            journal['state']='rolled_back';write_json(backup/'transaction.json',journal)
            raise
        result='적용 완료. 게임을 실행하고 BGM 편집의 곡 목록에서 추가한 곡을 선택하세요.'
        status(result)
        return result


def register(source,title,replace_id=None,bitrate=256,start=0,end=None,fade=5):
    validate_title(title)
    with lock():
        rows=load_library()
        if replace_id is None:
            if len(rows)>=11:raise ValueError('추가 11곡이 모두 등록되었습니다. 기존 추가곡을 선택해 교체할 수 있습니다.')
            logical=117+len(rows)
        else:
            if not any(r['id']==replace_id for r in rows):raise ValueError('교체할 추가곡 ID가 없습니다.')
            logical=replace_id
        with tempfile.TemporaryDirectory(prefix='encode-',dir=HERE) as td:
            audio=bank.convert(source,FFMPEG,td,bitrate,start,end,fade)
        name=bank.digest(audio)+'.ktac';atomic(LIB/name,audio)
        row=dict(id=logical,name=title.strip(),file=name,sha256=bank.digest(audio),bitrate=bitrate,**bank.validate_ktac(audio))
        if LIBRARY.exists():shutil.copy2(LIBRARY,LIB/('tracks.before_'+uuid.uuid4().hex+'.json'))
        if replace_id is None:rows.append(row)
        else:rows[logical-117]=row
        write_json(LIBRARY,rows)
        return row


def parse_time(text):
    parts=text.strip().split(':')
    if not 1<=len(parts)<=3:raise ValueError('시각 예: 01:30 또는 90')
    values=[float(p) for p in parts]
    if any(not math.isfinite(v) or v<0 for v in values) or any(v>=60 for v in values[1:]):raise ValueError('시각 범위 오류')
    value=0
    for v in values:value=value*60+v
    return value


def gui():
    import tkinter as tk
    from tkinter import ttk,filedialog,messagebox
    root=tk.Tk();root.title('삼국지14 CE — 추가 BGM 관리 (시험판)');root.geometry('840x665');root.minsize(790,630)
    root.option_add('*Font',('맑은 고딕',10))
    frame=ttk.Frame(root,padding=16);frame.pack(fill='both',expand=True)
    ttk.Label(frame,text='새 ID 117~127 · 기존 원곡 유지 · 원본 슬롯 크기 제한 없음',font=('맑은 고딕',12,'bold')).pack(anchor='w')
    ttk.Label(frame,text='게임 안 버튼에서 이 창을 엽니다. 등록 후 게임을 종료하고 [게임에 적용]을 누르세요.\nAAC 재인코딩은 손실 압축입니다. 선택한 비트레이트를 용량 때문에 자동으로 낮추지 않습니다.').pack(anchor='w',pady=8)
    tree=ttk.Treeview(frame,columns=('id','name','seconds','rate'),show='headings',height=8,selectmode='browse')
    for col,title,width in [('id','ID',60),('name','게임에 표시할 곡명',430),('seconds','길이(초)',95),('rate','kbps',65)]:
        tree.heading(col,text=title);tree.column(col,width=width,stretch=col=='name')
    tree.pack(fill='x')
    title=tk.StringVar();source=tk.StringVar();start=tk.StringVar(value='0:00');end=tk.StringVar();fade=tk.StringVar(value='5');rate=tk.StringVar(value='256')
    form=ttk.Frame(frame);form.pack(fill='x',pady=12);form.columnconfigure(1,weight=1)
    ttk.Label(form,text='MP3 / 음원 파일').grid(row=0,column=0,sticky='w');ttk.Entry(form,textvariable=source).grid(row=0,column=1,sticky='ew',padx=8)
    def choose():
        p=filedialog.askopenfilename(filetypes=[('음원','*.mp3 *.wav *.flac *.m4a *.ogg'),('모든 파일','*.*')])
        if p:source.set(p);title.set(Path(p).stem)
    ttk.Button(form,text='파일 선택',command=choose).grid(row=0,column=2)
    ttk.Label(form,text='곡명').grid(row=1,column=0,sticky='w',pady=8);ttk.Entry(form,textvariable=title).grid(row=1,column=1,columnspan=2,sticky='ew',padx=8)
    opts=ttk.Frame(frame);opts.pack(fill='x')
    for label,var in [('시작',start),('종료(빈칸=끝)',end),('페이드(초)',fade)]:
        ttk.Label(opts,text=label).pack(side='left',padx=(0,5));ttk.Entry(opts,textvariable=var,width=9).pack(side='left',padx=(0,14))
    ttk.Label(opts,text='AAC kbps').pack(side='left');ttk.Combobox(opts,textvariable=rate,values=('192','256','320'),state='readonly',width=5).pack(side='left',padx=6)
    status=tk.StringVar(value='준비 · 아직 추가 음악의 실제 게임 재생 검증은 완료되지 않았습니다.')
    ttk.Label(frame,textvariable=status,wraplength=780,foreground='#165e80').pack(fill='x',pady=16)
    messages=queue.Queue();busy=False;buttons=[]
    def refresh():
        tree.delete(*tree.get_children())
        for r in load_library():tree.insert('', 'end',iid=str(r['id']),values=(r['id'],r['name'],'%.2f'%r['seconds'],r['bitrate']))
    def selected():return int(tree.selection()[0]) if tree.selection() else None
    def selection(_):
        n=selected()
        if n is not None:title.set(next(r['name'] for r in load_library() if r['id']==n))
    tree.bind('<<TreeviewSelect>>',selection)
    def run(job):
        nonlocal busy
        if busy:return
        busy=True
        for b in buttons:b.configure(state='disabled')
        status.set('작업 중… 잠시 기다려 주세요. 게임 파일은 적용 버튼을 눌러야 변경됩니다.')
        def worker():
            try:
                result=job()
                messages.put(('done',result if isinstance(result,str) else '작업 완료. 등록/수정한 내용은 게임 종료 후 [게임에 적용]하세요.'))
            except Exception as e:messages.put(('error',str(e)))
        threading.Thread(target=worker,daemon=True).start()
    def add(replace=False):
        try:
            n=selected() if replace else None
            if replace and n is None:raise ValueError('교체할 추가곡을 선택하세요.')
            args=(source.get(),title.get(),n,int(rate.get()),parse_time(start.get()),parse_time(end.get()) if end.get().strip() else None,float(fade.get()))
            if not Path(args[0]).is_file():raise ValueError('음원 파일을 선택하세요.')
            run(lambda:register(*args))
        except Exception as e:messagebox.showerror('확인',str(e))
    def rename():
        try:
            n=selected();name=title.get();validate_title(name)
            if n is None:raise ValueError('추가곡을 선택하세요.')
            with lock():
                rows=load_library();rows[n-117]['name']=name.strip();write_json(LIBRARY,rows)
            refresh();status.set('곡명을 변경했습니다. 게임 종료 후 적용하세요.')
        except Exception as e:messagebox.showerror('확인',str(e))
    bar=ttk.Frame(frame);bar.pack(fill='x')
    for label,cmd in [('새 음악 등록',lambda:add(False)),('선택곡 음원 교체',lambda:add(True)),('선택곡 이름 변경',rename),('게임에 적용',lambda:run(lambda:apply(lambda s:messages.put(('status',s)))))]:
        b=ttk.Button(bar,text=label,command=cmd);b.pack(side='left',padx=(0,8));buttons.append(b)
    ttk.Label(frame,text='ID는 삭제·재정렬하지 않습니다. 기존 BGM 선택 설정이 다른 음악을 가리키는 것을 방지합니다.\n기존 117곡 교체는 종전 BGM 툴을 사용하세요. 이 창은 새로 추가한 곡 전용입니다.',foreground='#666666').pack(anchor='w',pady=14)
    def poll():
        nonlocal busy
        try:
            while True:
                kind,text=messages.get_nowait();status.set(text)
                if kind in ('done','error'):
                    busy=False
                    for b in buttons:b.configure(state='normal')
                    refresh()
                if kind=='error':messagebox.showerror('작업 중단',text)
        except queue.Empty:pass
        root.after(150,poll)
    def close():
        if busy:messagebox.showinfo('작업 중','변환/적용이 끝난 뒤 닫아 주세요.')
        else:root.destroy()
    root.protocol('WM_DELETE_WINDOW',close);refresh();poll();root.mainloop()


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--stage',action='store_true');parser.add_argument('--apply',action='store_true')
    args=parser.parse_args()
    if args.stage:
        with lock():print(stage_build())
    elif args.apply:apply()
    else:gui()
