namespace San14Patch101 { public static class ManifestHash { public const string Value="9298a4cbe3997495851a0e9462f19cdd337d5d77103853b08454742ac17c4a61"; } }
