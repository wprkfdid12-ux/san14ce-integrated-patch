namespace San14Patch101 { public static class ManifestHash { public const string Value="6241c076a8c86c446f0d539a49d33b13fd6abe8d91447832a7875ef72339642d"; } }
