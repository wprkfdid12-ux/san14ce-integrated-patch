namespace San14Patch101 { public static class ManifestHash { public const string Value="2ba82c46f2b37d2159231fceda82061be49ab2b8ac4604ebe836f4fd369ceb99"; } }
