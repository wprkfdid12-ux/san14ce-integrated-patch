namespace San14Patch101 { public static class ManifestHash { public const string Value="befe814691ea0135edd48e6056958cc651cec6857f80bf23d08ad4f1176705b6"; } }
