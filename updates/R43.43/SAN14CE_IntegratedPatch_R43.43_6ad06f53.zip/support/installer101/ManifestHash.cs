namespace San14Patch101 { public static class ManifestHash { public const string Value="0c4054f772ab9f435af352d31033af13d25df78d606e42396ea64f7eb73cf2eb"; } }
