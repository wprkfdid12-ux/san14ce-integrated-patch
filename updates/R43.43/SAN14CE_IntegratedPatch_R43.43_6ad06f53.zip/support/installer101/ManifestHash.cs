namespace San14Patch101 { public static class ManifestHash { public const string Value="112157dd7fc5ac7d37b222dde595e72a44f8f89deeac1858020b7e549efe3684"; } }
