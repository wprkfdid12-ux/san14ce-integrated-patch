namespace San14Patch101 { public static class ManifestHash { public const string Value="ec31a10a883a7e925f667023ff7a20b666ea085a27afed2519ce3562c9017e6c"; } }
