namespace San14Patch101 { public static class ManifestHash { public const string Value="54d898f7a17319a463187d95b4024dcad25abb7ddcf0132fde249e2adf81eaab"; } }
