namespace San14Patch101 { public static class ManifestHash { public const string Value="18750dbf391f212cc193180b49949c7ca98b2cd809a80e4452d25960486d5d8a"; } }
